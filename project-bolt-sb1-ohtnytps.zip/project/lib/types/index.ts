export type EducationLevel = 'middle-school' | 'high-school' | 'college';

export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type AssignmentStatus = 'not-started' | 'in-progress' | 'completed' | 'overdue';
export type AssignmentType = 'homework' | 'quiz' | 'test' | 'project' | 'essay' | 'lab' | 'presentation';

export type GradingSystem = 'points' | 'weighted';
export type GradeStatus = 'graded' | 'missing' | 'excused' | 'extra-credit';

export type EventType = 'assignment' | 'test' | 'study' | 'personal' | 'project';
export type NotificationType = 'assignment-due' | 'grade-posted' | 'test-approaching' | 'study-reminder' | 'system' | 'overdue' | 'grade-changed';

export type AIMode = 'hint' | 'explain' | 'step-by-step' | 'check-work' | 'teach';
export type AIRole = 'user' | 'assistant';

export type ThemeMode = 'light' | 'dark' | 'system';
export type AccentColor = 'blue' | 'green' | 'orange' | 'red' | 'teal' | 'amber' | 'rose' | 'cyan';

export interface Profile {
  id: string;
  full_name: string;
  education_level: EducationLevel;
  school_name: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Course {
  id: string;
  user_id: string;
  name: string;
  teacher: string;
  color: string;
  icon: string;
  period: string;
  room: string;
  grading_system: GradingSystem;
  created_at: string;
  updated_at: string;
}

export interface Assignment {
  id: string;
  user_id: string;
  course_id: string | null;
  title: string;
  description: string;
  due_date: string | null;
  due_time: string;
  priority: Priority;
  status: AssignmentStatus;
  estimated_minutes: number;
  points_possible: number;
  points_earned: number | null;
  assignment_type: AssignmentType;
  lms_link: string | null;
  lms_id: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface Subtask {
  id: string;
  assignment_id: string;
  title: string;
  completed: boolean;
  sort_order: number;
  created_at: string;
}

export interface GradeCategory {
  id: string;
  course_id: string;
  name: string;
  weight: number;
  drop_lowest: number;
  created_at: string;
}

export interface Grade {
  id: string;
  user_id: string;
  course_id: string | null;
  assignment_id: string | null;
  category_id: string | null;
  title: string;
  points_earned: number | null;
  points_possible: number;
  status: GradeStatus;
  graded_date: string | null;
  created_at: string;
}

export interface CalendarEvent {
  id: string;
  user_id: string;
  title: string;
  description: string;
  event_date: string;
  start_time: string | null;
  end_time: string | null;
  event_type: EventType;
  course_id: string | null;
  assignment_id: string | null;
  location: string;
  created_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  assignment_id: string | null;
  course_id: string | null;
  title: string;
  session_date: string;
  start_time: string | null;
  duration_minutes: number;
  completed: boolean;
  created_at: string;
}

export interface PlannerTask {
  id: string;
  assignment_id: string;
  title: string;
  planned_date: string;
  duration_minutes: number;
  completed: boolean;
  sort_order: number;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  notification_type: NotificationType;
  related_id: string | null;
  is_read: boolean;
  created_at: string;
}

export interface ThemePreference {
  id: string;
  user_id: string;
  theme: ThemeMode;
  accent_color: AccentColor;
  preset: string;
  created_at: string;
  updated_at: string;
}

export interface AIConversation {
  id: string;
  user_id: string;
  title: string;
  course_id: string | null;
  assignment_id: string | null;
  mode: AIMode;
  created_at: string;
  updated_at: string;
}

export interface AIMessage {
  id: string;
  conversation_id: string;
  role: AIRole;
  content: string;
  created_at: string;
}

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Partial<Profile>;
        Update: Partial<Profile>;
      };
      courses: {
        Row: Course;
        Insert: Partial<Course>;
        Update: Partial<Course>;
      };
      assignments: {
        Row: Assignment;
        Insert: Partial<Assignment>;
        Update: Partial<Assignment>;
      };
      subtasks: {
        Row: Subtask;
        Insert: Partial<Subtask>;
        Update: Partial<Subtask>;
      };
      grade_categories: {
        Row: GradeCategory;
        Insert: Partial<GradeCategory>;
        Update: Partial<GradeCategory>;
      };
      grades: {
        Row: Grade;
        Insert: Partial<Grade>;
        Update: Partial<Grade>;
      };
      calendar_events: {
        Row: CalendarEvent;
        Insert: Partial<CalendarEvent>;
        Update: Partial<CalendarEvent>;
      };
      study_sessions: {
        Row: StudySession;
        Insert: Partial<StudySession>;
        Update: Partial<StudySession>;
      };
      planner_tasks: {
        Row: PlannerTask;
        Insert: Partial<PlannerTask>;
        Update: Partial<PlannerTask>;
      };
      notifications: {
        Row: Notification;
        Insert: Partial<Notification>;
        Update: Partial<Notification>;
      };
      theme_preferences: {
        Row: ThemePreference;
        Insert: Partial<ThemePreference>;
        Update: Partial<ThemePreference>;
      };
      ai_conversations: {
        Row: AIConversation;
        Insert: Partial<AIConversation>;
        Update: Partial<AIConversation>;
      };
      ai_messages: {
        Row: AIMessage;
        Insert: Partial<AIMessage>;
        Update: Partial<AIMessage>;
      };
    };
  };
}
