import type { Grade, GradeCategory, Course } from '@/lib/types';

export interface GradeResult {
  percentage: number;
  letterGrade: string;
  gpa: number;
  details: CategoryDetail[];
}

export interface CategoryDetail {
  categoryName: string;
  weight: number;
  earned: number;
  possible: number;
  percentage: number;
  count: number;
}

const LETTER_GRADES: { min: number; letter: string; gpa: number }[] = [
  { min: 93, letter: 'A', gpa: 4.0 },
  { min: 90, letter: 'A-', gpa: 3.7 },
  { min: 87, letter: 'B+', gpa: 3.3 },
  { min: 83, letter: 'B', gpa: 3.0 },
  { min: 80, letter: 'B-', gpa: 2.7 },
  { min: 77, letter: 'C+', gpa: 2.3 },
  { min: 73, letter: 'C', gpa: 2.0 },
  { min: 70, letter: 'C-', gpa: 1.7 },
  { min: 67, letter: 'D+', gpa: 1.3 },
  { min: 63, letter: 'D', gpa: 1.0 },
  { min: 60, letter: 'D-', gpa: 0.7 },
  { min: 0, letter: 'F', gpa: 0.0 },
];

export function getLetterGrade(percentage: number): string {
  return LETTER_GRADES.find((g) => percentage >= g.min)?.letter ?? 'F';
}

export function getGPAFromPercentage(percentage: number): number {
  return LETTER_GRADES.find((g) => percentage >= g.min)?.gpa ?? 0.0;
}

export function calculatePointsGrade(grades: Grade[]): GradeResult {
  const valid = grades.filter((g) => g.status === 'graded' || g.status === 'extra-credit');
  const earned = valid.reduce((sum, g) => sum + (g.points_earned ?? 0), 0);
  const possible = valid.reduce((sum, g) => sum + g.points_possible, 0);

  const percentage = possible > 0 ? (earned / possible) * 100 : 0;
  const letterGrade = getLetterGrade(percentage);
  const gpa = getGPAFromPercentage(percentage);

  return {
    percentage,
    letterGrade,
    gpa,
    details: [{
      categoryName: 'All',
      weight: 100,
      earned,
      possible,
      percentage: possible > 0 ? (earned / possible) * 100 : 0,
      count: valid.length,
    }],
  };
}

export function calculateWeightedGrade(grades: Grade[], categories: GradeCategory[]): GradeResult {
  const details: CategoryDetail[] = [];
  let totalWeightedPercentage = 0;
  let totalWeight = 0;

  for (const cat of categories) {
    const catGrades = grades.filter((g) => g.category_id === cat.id && g.status === 'graded');

    let sortedGrades = [...catGrades];
    if (cat.drop_lowest > 0 && sortedGrades.length > cat.drop_lowest) {
      sortedGrades.sort((a, b) => {
        const aPct = (a.points_earned ?? 0) / a.points_possible;
        const bPct = (b.points_earned ?? 0) / b.points_possible;
        return aPct - bPct;
      });
      sortedGrades = sortedGrades.slice(cat.drop_lowest);
    }

    const earned = sortedGrades.reduce((sum, g) => sum + (g.points_earned ?? 0), 0);
    const possible = sortedGrades.reduce((sum, g) => sum + g.points_possible, 0);
    const pct = possible > 0 ? (earned / possible) * 100 : 0;

    details.push({
      categoryName: cat.name,
      weight: cat.weight,
      earned,
      possible,
      percentage: pct,
      count: sortedGrades.length,
    });

    if (possible > 0) {
      totalWeightedPercentage += (pct * cat.weight) / 100;
      totalWeight += cat.weight;
    }
  }

  const percentage = totalWeight > 0 ? (totalWeightedPercentage / totalWeight) * 100 : 0;
  const letterGrade = getLetterGrade(percentage);
  const gpa = getGPAFromPercentage(percentage);

  return { percentage, letterGrade, gpa, details };
}

export function calculateCourseGrade(course: Course, grades: Grade[], categories: GradeCategory[]): GradeResult {
  if (course.grading_system === 'weighted' && categories.length > 0) {
    return calculateWeightedGrade(grades, categories);
  }
  return calculatePointsGrade(grades);
}

export interface WhatIfAssignment {
  categoryId: string | null;
  pointsEarned: number;
  pointsPossible: number;
  title: string;
}

export function calculateWhatIf(
  course: Course,
  existingGrades: Grade[],
  categories: GradeCategory[],
  hypothetical: WhatIfAssignment[]
): { currentGrade: GradeResult; projectedGrade: GradeResult; difference: number } {
  const currentGrade = calculateCourseGrade(course, existingGrades, categories);

  const allGrades = [...existingGrades, ...hypothetical.map((h) => ({
    id: 'hypothetical',
    user_id: '',
    course_id: course.id,
    assignment_id: null,
    category_id: h.categoryId,
    title: h.title,
    points_earned: h.pointsEarned,
    points_possible: h.pointsPossible,
    status: 'graded' as const,
    graded_date: null,
    created_at: '',
  }))];

  const projectedGrade = calculateCourseGrade(course, allGrades, categories);
  const difference = projectedGrade.percentage - currentGrade.percentage;

  return { currentGrade, projectedGrade, difference };
}

export function calculateGPA(courseResults: { percentage: number; isWeighted: boolean; weight: number }[]): {
  unweighted: number;
  weighted: number;
} {
  if (courseResults.length === 0) return { unweighted: 0, weighted: 0 };

  const unweighted = courseResults.reduce((sum, c) => sum + getGPAFromPercentage(c.percentage), 0) / courseResults.length;
  const totalWeight = courseResults.reduce((sum, c) => sum + c.weight, 0);
  const weighted = courseResults.reduce((sum, c) => sum + getGPAFromPercentage(c.percentage) * c.weight, 0) / (totalWeight || 1);

  return { unweighted, weighted };
}
