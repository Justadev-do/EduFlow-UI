'use client';

import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { supabase } from '@/lib/supabase/client';
import { useAuth } from '@/lib/auth-context';
import type { ThemeMode, AccentColor } from '@/lib/types';

export interface ThemePreset {
  id: string;
  name: string;
  mode: ThemeMode;
  accent: AccentColor;
  vars: Record<string, string>;
}

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'default',
    name: 'Default',
    mode: 'light',
    accent: 'blue',
    vars: {
      '--background': '0 0% 100%',
      '--foreground': '222 47% 11%',
      '--card': '0 0% 100%',
      '--card-foreground': '222 47% 11%',
      '--primary': '221 83% 53%',
      '--primary-foreground': '0 0% 100%',
      '--secondary': '210 40% 96%',
      '--secondary-foreground': '222 47% 11%',
      '--muted': '210 40% 96%',
      '--muted-foreground': '215 16% 47%',
      '--accent': '210 40% 96%',
      '--accent-foreground': '222 47% 11%',
      '--border': '214 32% 91%',
      '--input': '214 32% 91%',
      '--ring': '221 83% 53%',
      '--destructive': '0 84% 60%',
      '--destructive-foreground': '0 0% 98%',
    },
  },
  {
    id: 'midnight',
    name: 'Midnight',
    mode: 'dark',
    accent: 'blue',
    vars: {
      '--background': '222 47% 6%',
      '--foreground': '210 40% 98%',
      '--card': '222 47% 9%',
      '--card-foreground': '210 40% 98%',
      '--primary': '217 91% 60%',
      '--primary-foreground': '222 47% 11%',
      '--secondary': '217 33% 17%',
      '--secondary-foreground': '210 40% 98%',
      '--muted': '217 33% 17%',
      '--muted-foreground': '215 20% 65%',
      '--accent': '217 33% 17%',
      '--accent-foreground': '210 40% 98%',
      '--border': '217 33% 20%',
      '--input': '217 33% 20%',
      '--ring': '217 91% 60%',
      '--destructive': '0 63% 31%',
      '--destructive-foreground': '210 40% 98%',
    },
  },
  {
    id: 'ocean',
    name: 'Ocean',
    mode: 'dark',
    accent: 'cyan',
    vars: {
      '--background': '199 50% 8%',
      '--foreground': '186 60% 95%',
      '--card': '199 45% 11%',
      '--card-foreground': '186 60% 95%',
      '--primary': '187 85% 53%',
      '--primary-foreground': '199 50% 8%',
      '--secondary': '199 40% 18%',
      '--secondary-foreground': '186 60% 95%',
      '--muted': '199 40% 18%',
      '--muted-foreground': '186 30% 60%',
      '--accent': '199 40% 18%',
      '--accent-foreground': '186 60% 95%',
      '--border': '199 35% 22%',
      '--input': '199 35% 22%',
      '--ring': '187 85% 53%',
      '--destructive': '0 63% 31%',
      '--destructive-foreground': '186 60% 95%',
    },
  },
  {
    id: 'forest',
    name: 'Forest',
    mode: 'dark',
    accent: 'green',
    vars: {
      '--background': '149 30% 8%',
      '--foreground': '140 30% 95%',
      '--card': '149 28% 11%',
      '--card-foreground': '140 30% 95%',
      '--primary': '142 71% 45%',
      '--primary-foreground': '149 30% 8%',
      '--secondary': '149 25% 18%',
      '--secondary-foreground': '140 30% 95%',
      '--muted': '149 25% 18%',
      '--muted-foreground': '140 20% 60%',
      '--accent': '149 25% 18%',
      '--accent-foreground': '140 30% 95%',
      '--border': '149 22% 22%',
      '--input': '149 22% 22%',
      '--ring': '142 71% 45%',
      '--destructive': '0 63% 31%',
      '--destructive-foreground': '140 30% 95%',
    },
  },
  {
    id: 'sunset',
    name: 'Sunset',
    mode: 'light',
    accent: 'orange',
    vars: {
      '--background': '30 50% 98%',
      '--foreground': '20 14% 12%',
      '--card': '0 0% 100%',
      '--card-foreground': '20 14% 12%',
      '--primary': '24 95% 53%',
      '--primary-foreground': '0 0% 100%',
      '--secondary': '30 40% 94%',
      '--secondary-foreground': '20 14% 12%',
      '--muted': '30 40% 94%',
      '--muted-foreground': '25 5% 45%',
      '--accent': '30 40% 94%',
      '--accent-foreground': '20 14% 12%',
      '--border': '30 20% 88%',
      '--input': '30 20% 88%',
      '--ring': '24 95% 53%',
      '--destructive': '0 84% 60%',
      '--destructive-foreground': '0 0% 98%',
    },
  },
  {
    id: 'lavender',
    name: 'Lavender',
    mode: 'light',
    accent: 'rose',
    vars: {
      '--background': '280 30% 99%',
      '--foreground': '280 30% 12%',
      '--card': '0 0% 100%',
      '--card-foreground': '280 30% 12%',
      '--primary': '280 60% 50%',
      '--primary-foreground': '0 0% 100%',
      '--secondary': '280 30% 94%',
      '--secondary-foreground': '280 30% 12%',
      '--muted': '280 30% 94%',
      '--muted-foreground': '280 10% 45%',
      '--accent': '280 30% 94%',
      '--accent-foreground': '280 30% 12%',
      '--border': '280 20% 88%',
      '--input': '280 20% 88%',
      '--ring': '280 60% 50%',
      '--destructive': '0 84% 60%',
      '--destructive-foreground': '0 0% 98%',
    },
  },
  {
    id: 'minimal',
    name: 'Minimal',
    mode: 'light',
    accent: 'blue',
    vars: {
      '--background': '0 0% 100%',
      '--foreground': '0 0% 9%',
      '--card': '0 0% 100%',
      '--card-foreground': '0 0% 9%',
      '--primary': '0 0% 9%',
      '--primary-foreground': '0 0% 98%',
      '--secondary': '0 0% 96%',
      '--secondary-foreground': '0 0% 9%',
      '--muted': '0 0% 96%',
      '--muted-foreground': '0 0% 45%',
      '--accent': '0 0% 96%',
      '--accent-foreground': '0 0% 9%',
      '--border': '0 0% 90%',
      '--input': '0 0% 90%',
      '--ring': '0 0% 9%',
      '--destructive': '0 84% 60%',
      '--destructive-foreground': '0 0% 98%',
    },
  },
  {
    id: 'high-contrast',
    name: 'High Contrast',
    mode: 'dark',
    accent: 'amber',
    vars: {
      '--background': '0 0% 0%',
      '--foreground': '0 0% 100%',
      '--card': '0 0% 5%',
      '--card-foreground': '0 0% 100%',
      '--primary': '45 96% 53%',
      '--primary-foreground': '0 0% 0%',
      '--secondary': '0 0% 15%',
      '--secondary-foreground': '0 0% 100%',
      '--muted': '0 0% 15%',
      '--muted-foreground': '0 0% 80%',
      '--accent': '0 0% 15%',
      '--accent-foreground': '0 0% 100%',
      '--border': '0 0% 25%',
      '--input': '0 0% 25%',
      '--ring': '45 96% 53%',
      '--destructive': '0 100% 50%',
      '--destructive-foreground': '0 0% 100%',
    },
  },
];

export const ACCENT_COLORS: Record<AccentColor, string> = {
  blue: '221 83% 53%',
  green: '142 71% 45%',
  orange: '24 95% 53%',
  red: '0 84% 60%',
  teal: '173 80% 40%',
  amber: '45 96% 53%',
  rose: '347 77% 55%',
  cyan: '187 85% 53%',
};

interface ThemeContextValue {
  preset: string;
  mode: ThemeMode;
  accent: AccentColor;
  setPreset: (preset: string) => void;
  setMode: (mode: ThemeMode) => void;
  setAccent: (accent: AccentColor) => void;
  loading: boolean;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [preset, setPresetState] = useState<string>('default');
  const [mode, setModeState] = useState<ThemeMode>('system');
  const [accent, setAccentState] = useState<AccentColor>('blue');
  const [loading, setLoading] = useState(true);

  const applyTheme = useCallback((presetId: string, accentColor: AccentColor, themeMode: ThemeMode) => {
    const p = THEME_PRESETS.find((t) => t.id === presetId) ?? THEME_PRESETS[0];
    const root = document.documentElement;

    Object.entries(p.vars).forEach(([key, value]) => {
      root.style.setProperty(key, value);
    });

    const accentHsl = ACCENT_COLORS[accentColor];
    root.style.setProperty('--primary', accentHsl);
    root.style.setProperty('--ring', accentHsl);

    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isDark = themeMode === 'dark' || (themeMode === 'system' && p.mode === 'dark') ||
      (themeMode === 'system' && prefersDark && p.mode !== 'light');
    if (isDark || p.mode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, []);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      const saved = localStorage.getItem('eduflow-theme');
      if (saved) {
        try {
          const t = JSON.parse(saved);
          setPresetState(t.preset ?? 'default');
          setModeState(t.mode ?? 'system');
          setAccentState(t.accent ?? 'blue');
          applyTheme(t.preset ?? 'default', t.accent ?? 'blue', t.mode ?? 'system');
        } catch { /* ignore */ }
      } else {
        applyTheme('default', 'blue', 'system');
      }
      return;
    }

    supabase
      .from('theme_preferences')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setPresetState(data.preset);
          setModeState(data.theme);
          setAccentState(data.accent_color);
          applyTheme(data.preset, data.accent_color, data.theme);
        } else {
          applyTheme('default', 'blue', 'system');
        }
        setLoading(false);
      });
  }, [user, applyTheme]);

  const saveTheme = useCallback(async (newPreset: string, newMode: ThemeMode, newAccent: AccentColor) => {
    if (user) {
      await supabase.from('theme_preferences').upsert({
        user_id: user.id,
        preset: newPreset,
        theme: newMode,
        accent_color: newAccent,
      });
    } else {
      localStorage.setItem('eduflow-theme', JSON.stringify({ preset: newPreset, mode: newMode, accent: newAccent }));
    }
  }, [user]);

  const setPreset = useCallback((p: string) => {
    setPresetState(p);
    applyTheme(p, accent, mode);
    saveTheme(p, mode, accent);
  }, [accent, mode, applyTheme, saveTheme]);

  const setMode = useCallback((m: ThemeMode) => {
    setModeState(m);
    applyTheme(preset, accent, m);
    saveTheme(preset, m, accent);
  }, [preset, accent, applyTheme, saveTheme]);

  const setAccent = useCallback((a: AccentColor) => {
    setAccentState(a);
    applyTheme(preset, a, mode);
    saveTheme(preset, mode, a);
  }, [preset, mode, applyTheme, saveTheme]);

  return (
    <ThemeContext.Provider value={{ preset, mode, accent, setPreset, setMode, setAccent, loading }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
