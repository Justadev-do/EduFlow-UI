import { cn } from '@/lib/utils';

export function getLetterGradeColor(letter: string): string {
  if (letter.startsWith('A')) return 'text-emerald-600 dark:text-emerald-400';
  if (letter.startsWith('B')) return 'text-blue-600 dark:text-blue-400';
  if (letter.startsWith('C')) return 'text-amber-600 dark:text-amber-400';
  if (letter.startsWith('D')) return 'text-orange-600 dark:text-orange-400';
  return 'text-red-600 dark:text-red-400';
}

export { getCourseColor } from '@/lib/date-utils';
