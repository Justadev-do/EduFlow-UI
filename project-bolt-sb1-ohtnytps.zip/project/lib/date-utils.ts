import { format, parseISO, isToday, isTomorrow, isPast, differenceInDays, addDays, startOfWeek, endOfWeek, eachDayOfInterval, startOfMonth, endOfMonth, isSameDay, isSameMonth } from 'date-fns';

export { format, parseISO, isToday, isTomorrow, isPast, differenceInDays, addDays, startOfWeek, endOfWeek, eachDayOfInterval, startOfMonth, endOfMonth, isSameDay, isSameMonth };

export function formatDueLabel(dateStr: string | null, time: string): string {
  if (!dateStr) return 'No due date';
  const date = parseISO(dateStr);
  if (isToday(date)) return `Due today · ${time}`;
  if (isTomorrow(date)) return `Due tomorrow · ${time}`;
  const diff = differenceInDays(date, new Date());
  if (diff < 0) return `Overdue by ${Math.abs(diff)}d`;
  if (diff <= 7) return `Due in ${diff}d · ${time}`;
  return `Due ${format(date, 'MMM d')} · ${time}`;
}

export function formatShortDate(dateStr: string | null): string {
  if (!dateStr) return '';
  return format(parseISO(dateStr), 'MMM d');
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export function isDueToday(dateStr: string | null): boolean {
  if (!dateStr) return false;
  return isToday(parseISO(dateStr));
}

export function isOverdue(dateStr: string | null, status: string): boolean {
  if (!dateStr || status === 'completed') return false;
  return isPast(parseISO(dateStr)) && !isToday(parseISO(dateStr));
}

export function isDueThisWeek(dateStr: string | null): boolean {
  if (!dateStr) return false;
  const date = parseISO(dateStr);
  const now = new Date();
  const weekEnd = endOfWeek(now, { weekStartsOn: 1 });
  return date <= weekEnd && date >= now;
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export function getPriorityColor(priority: string): string {
  switch (priority) {
    case 'critical': return 'text-red-600 dark:text-red-400';
    case 'high': return 'text-orange-600 dark:text-orange-400';
    case 'medium': return 'text-amber-600 dark:text-amber-400';
    case 'low': return 'text-green-600 dark:text-green-400';
    default: return 'text-muted-foreground';
  }
}

export function getPriorityBg(priority: string): string {
  switch (priority) {
    case 'critical': return 'bg-red-500/10 border-red-500/30';
    case 'high': return 'bg-orange-500/10 border-orange-500/30';
    case 'medium': return 'bg-amber-500/10 border-amber-500/30';
    case 'low': return 'bg-green-500/10 border-green-500/30';
    default: return 'bg-muted';
  }
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'completed': return 'text-green-600 dark:text-green-400';
    case 'in-progress': return 'text-blue-600 dark:text-blue-400';
    case 'overdue': return 'text-red-600 dark:text-red-400';
    default: return 'text-muted-foreground';
  }
}

export const COURSE_COLORS: Record<string, { bg: string; text: string; border: string; dot: string }> = {
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-600 dark:text-blue-400', border: 'border-blue-500/30', dot: 'bg-blue-500' },
  green: { bg: 'bg-emerald-500/10', text: 'text-emerald-600 dark:text-emerald-400', border: 'border-emerald-500/30', dot: 'bg-emerald-500' },
  orange: { bg: 'bg-orange-500/10', text: 'text-orange-600 dark:text-orange-400', border: 'border-orange-500/30', dot: 'bg-orange-500' },
  red: { bg: 'bg-red-500/10', text: 'text-red-600 dark:text-red-400', border: 'border-red-500/30', dot: 'bg-red-500' },
  purple: { bg: 'bg-violet-500/10', text: 'text-violet-600 dark:text-violet-400', border: 'border-violet-500/30', dot: 'bg-violet-500' },
  teal: { bg: 'bg-teal-500/10', text: 'text-teal-600 dark:text-teal-400', border: 'border-teal-500/30', dot: 'bg-teal-500' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-600 dark:text-amber-400', border: 'border-amber-500/30', dot: 'bg-amber-500' },
  rose: { bg: 'bg-rose-500/10', text: 'text-rose-600 dark:text-rose-400', border: 'border-rose-500/30', dot: 'bg-rose-500' },
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-600 dark:text-cyan-400', border: 'border-cyan-500/30', dot: 'bg-cyan-500' },
  indigo: { bg: 'bg-indigo-500/10', text: 'text-indigo-600 dark:text-indigo-400', border: 'border-indigo-500/30', dot: 'bg-indigo-500' },
};

export function getCourseColor(color: string) {
  return COURSE_COLORS[color] ?? COURSE_COLORS.blue;
}
