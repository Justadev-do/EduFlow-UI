'use client';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { formatDueLabel, formatDuration, getPriorityBg, getCourseColor } from '@/lib/date-utils';
import type { Assignment, Course } from '@/lib/types';
import { Play, Check, ExternalLink, Sparkles, Clock } from 'lucide-react';
import { useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import { toast } from 'sonner';
import Link from 'next/link';

interface AssignmentCardProps {
  assignment: Assignment;
  course?: Course;
  onNavigate?: (id: string) => void;
}

export function AssignmentCard({ assignment, course, onNavigate }: AssignmentCardProps) {
  const [status, setStatus] = useState(assignment.status);
  const [updating, setUpdating] = useState(false);
  const courseColor = course ? getCourseColor(course.color) : getCourseColor('blue');

  const updateStatus = async (newStatus: string) => {
    setUpdating(true);
    const { error } = await supabase
      .from('assignments')
      .update({ status: newStatus })
      .eq('id', assignment.id);
    if (error) {
      toast.error('Failed to update assignment');
    } else {
      setStatus(newStatus as any);
      if (newStatus === 'completed') toast.success('Assignment completed!');
    }
    setUpdating(false);
  };

  const isCompleted = status === 'completed';

  return (
    <Card
      className={cn(
        'p-4 border-l-4 transition-all hover:shadow-md cursor-pointer group',
        getPriorityBg(assignment.priority),
        isCompleted && 'opacity-60'
      )}
      onClick={() => onNavigate?.(assignment.id)}
    >
      <div className="flex items-start gap-3">
        <div className="pt-0.5">
          <Checkbox
            checked={isCompleted}
            disabled={updating}
            onClick={(e) => e.stopPropagation()}
            onCheckedChange={(checked) => {
              updateStatus(checked ? 'completed' : 'not-started');
            }}
          />
        </div>

        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center gap-2">
            {course && (
              <span className={cn('text-xs font-medium px-2 py-0.5 rounded-md', courseColor.bg, courseColor.text)}>
                {course.name}
              </span>
            )}
            <span className="text-xs text-muted-foreground capitalize">{assignment.assignment_type}</span>
          </div>

          <h3 className={cn('font-semibold text-sm leading-tight', isCompleted && 'line-through')}>
            {assignment.title}
          </h3>

          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className={cn(
              assignment.due_date && new Date(assignment.due_date) < new Date() && !isCompleted
                ? 'text-red-600 dark:text-red-400 font-medium'
                : ''
            )}>
              {formatDueLabel(assignment.due_date, assignment.due_time)}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatDuration(assignment.estimated_minutes)}
            </span>
          </div>

          <div className="flex items-center gap-2 pt-1" onClick={(e) => e.stopPropagation()}>
            {!isCompleted && status !== 'in-progress' && (
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs"
                disabled={updating}
                onClick={() => updateStatus('in-progress')}
              >
                <Play className="w-3 h-3 mr-1" />
                Start
              </Button>
            )}
            {!isCompleted && (
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs"
                disabled={updating}
                onClick={() => updateStatus('completed')}
              >
                <Check className="w-3 h-3 mr-1" />
                Complete
              </Button>
            )}
            {assignment.lms_link && (
              <a href={assignment.lms_link} target="_blank" rel="noopener noreferrer">
                <Button size="sm" variant="ghost" className="h-7 text-xs">
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Canvas
                </Button>
              </a>
            )}
            <Link href={`/ai?assignment=${assignment.id}`} onClick={(e) => e.stopPropagation()}>
              <Button size="sm" variant="ghost" className="h-7 text-xs">
                <Sparkles className="w-3 h-3 mr-1" />
                Help
              </Button>
            </Link>
          </div>
        </div>

        <div className="shrink-0">
          <Badge
            variant="outline"
            className={cn(
              'text-xs capitalize',
              assignment.priority === 'critical' && 'border-red-500/50 text-red-600 dark:text-red-400',
              assignment.priority === 'high' && 'border-orange-500/50 text-orange-600 dark:text-orange-400',
              assignment.priority === 'medium' && 'border-amber-500/50 text-amber-600 dark:text-amber-400',
              assignment.priority === 'low' && 'border-green-500/50 text-green-600 dark:text-green-400',
            )}
          >
            {assignment.priority}
          </Badge>
        </div>
      </div>
    </Card>
  );
}
