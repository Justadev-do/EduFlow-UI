'use client';

import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { getCourseColor, getLetterGradeColor } from '@/lib/course-utils';
import type { Course } from '@/lib/types';
import Link from 'next/link';
import { BookOpen, ChevronRight } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

interface CourseCardProps {
  course: Course;
  currentGrade?: string;
  upcomingCount?: number;
}

export function CourseCard({ course, currentGrade, upcomingCount = 0 }: CourseCardProps) {
  const colors = getCourseColor(course.color);
  const Icon = (LucideIcons as any)[course.icon] ?? BookOpen;

  return (
    <Link href={`/classes/${course.id}`}>
      <Card className={cn('p-4 hover:shadow-lg transition-all cursor-pointer group border-l-4', colors.border)}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className={cn('flex items-center justify-center w-10 h-10 rounded-lg shrink-0', colors.bg)}>
              <Icon className={cn('w-5 h-5', colors.text)} />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-sm truncate">{course.name}</h3>
              <p className="text-xs text-muted-foreground truncate">
                {course.teacher || 'No teacher assigned'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:translate-x-1 transition-transform shrink-0" />
        </div>

        <div className="flex items-center justify-between mt-4 pt-3 border-t">
          <div className="flex items-center gap-2">
            {currentGrade ? (
              <span className={cn('text-lg font-bold', getLetterGradeColor(currentGrade))}>
                {currentGrade}
              </span>
            ) : (
              <span className="text-xs text-muted-foreground">No grade yet</span>
            )}
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            {upcomingCount > 0 && (
              <span className="px-2 py-0.5 rounded-md bg-muted">
                {upcomingCount} upcoming
              </span>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}
