'use client';

import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info';
  sublabel?: string;
}

const VARIANT_STYLES = {
  default: 'text-foreground',
  success: 'text-emerald-600 dark:text-emerald-400',
  warning: 'text-amber-600 dark:text-amber-400',
  danger: 'text-red-600 dark:text-red-400',
  info: 'text-blue-600 dark:text-blue-400',
};

const ICON_BG = {
  default: 'bg-muted',
  success: 'bg-emerald-500/10',
  warning: 'bg-amber-500/10',
  danger: 'bg-red-500/10',
  info: 'bg-blue-500/10',
};

export function StatCard({ label, value, icon: Icon, variant = 'default', sublabel }: StatCardProps) {
  return (
    <Card className="p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <p className={cn('text-2xl font-bold mt-1', VARIANT_STYLES[variant])}>{value}</p>
          {sublabel && <p className="text-xs text-muted-foreground mt-1">{sublabel}</p>}
        </div>
        <div className={cn('flex items-center justify-center w-10 h-10 rounded-lg shrink-0', ICON_BG[variant])}>
          <Icon className={cn('w-5 h-5', VARIANT_STYLES[variant])} />
        </div>
      </div>
    </Card>
  );
}
