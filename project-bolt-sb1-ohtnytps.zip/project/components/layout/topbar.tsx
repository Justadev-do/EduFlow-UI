'use client';

import Link from 'next/link';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MobileNav } from '@/components/layout/sidebar';
import { Bell, Search, GraduationCap as EduLogo } from 'lucide-react';
import { usePathname } from 'next/navigation';

export function TopBar() {
  const { profile, user } = useAuth();
  const pathname = usePathname();

  const initials = (profile?.full_name || user?.email || 'U')
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  const pageTitle = pathname.split('/').filter(Boolean).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') || 'Dashboard';

  return (
    <header className="sticky top-0 z-40 flex items-center gap-3 h-16 px-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <MobileNav />
      <div className="flex items-center gap-2 md:hidden">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground">
          <EduLogo className="w-5 h-5" />
        </div>
      </div>
      <h1 className="hidden md:block text-lg font-semibold tracking-tight capitalize">{pageTitle}</h1>

      <div className="flex-1 max-w-md mx-auto md:mx-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search assignments, classes, grades..."
            className="w-full h-9 pl-9 pr-3 rounded-lg bg-muted text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        <Link href="/notifications">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary" />
          </Button>
        </Link>
        <Link href="/settings">
          <Avatar className="w-8 h-8 cursor-pointer">
            <AvatarFallback className="text-xs bg-primary text-primary-foreground">{initials}</AvatarFallback>
          </Avatar>
        </Link>
      </div>
    </header>
  );
}
