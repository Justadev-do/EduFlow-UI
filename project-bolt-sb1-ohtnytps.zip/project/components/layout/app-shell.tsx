'use client';

import { ReactNode, useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Sidebar, MobileBottomNav } from '@/components/layout/sidebar';
import { TopBar } from '@/components/layout/topbar';
import { GraduationCap } from 'lucide-react';

const AUTH_ROUTES = ['/auth/sign-in', '/auth/sign-up', '/onboarding'];

export function AppShell({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  const isAuthRoute = AUTH_ROUTES.some((r) => pathname.startsWith(r));

  useEffect(() => {
    if (!loading) {
      if (!user && !isAuthRoute) {
        router.push('/auth/sign-in');
      } else if (user && pathname === '/auth/sign-in') {
        router.push('/dashboard');
      }
    }
  }, [user, loading, isAuthRoute, pathname, router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary text-primary-foreground animate-pulse">
            <GraduationCap className="w-7 h-7" />
          </div>
          <p className="text-sm text-muted-foreground">Loading EduFlow...</p>
        </div>
      </div>
    );
  }

  if (isAuthRoute) {
    return <>{children}</>;
  }

  if (!user) {
    return null;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />
        <main className="flex-1 p-4 md:p-6 pb-20 md:pb-6 overflow-auto">
          {children}
        </main>
      </div>
      <MobileBottomNav />
    </div>
  );
}
