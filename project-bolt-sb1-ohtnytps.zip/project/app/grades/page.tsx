'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Course, Grade, GradeCategory } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { calculateCourseGrade, calculateWhatIf, getLetterGrade, type WhatIfAssignment } from '@/lib/grading';
import { getLetterGradeColor, getCourseColor } from '@/lib/course-utils';
import { cn } from '@/lib/utils';
import { Plus, GraduationCap, TrendingUp, Calculator } from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';

export default function GradesPage() {
  return (
    <AppShell>
      <GradesContent />
    </AppShell>
  );
}

function GradesContent() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [categories, setCategories] = useState<GradeCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddGrade, setShowAddGrade] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const loadData = async () => {
    if (!user) return;
    const [cRes, gRes] = await Promise.all([
      supabase.from('courses').select('*').eq('user_id', user.id),
      supabase.from('grades').select('*').eq('user_id', user.id),
    ]);
    setCourses((cRes.data as Course[]) ?? []);
    setGrades((gRes.data as Grade[]) ?? []);
    const catPromises = ((cRes.data as Course[]) ?? []).map((c) =>
      supabase.from('grade_categories').select('*').eq('course_id', c.id)
    );
    const catResults = await Promise.all(catPromises);
    setCategories(catResults.flatMap((r) => (r.data as GradeCategory[]) ?? []));
    setLoading(false);
  };

  useEffect(() => { loadData(); }, [user]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Grades</h2>
          <p className="text-sm text-muted-foreground">Track your academic performance</p>
        </div>
        <Button onClick={() => setShowAddGrade(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Grade
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : courses.length === 0 ? (
        <Card className="p-12 text-center">
          <GraduationCap className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-lg">No grades yet</h3>
          <p className="text-sm text-muted-foreground mt-1">Add a class and start entering grades to see your performance.</p>
          <Link href="/classes">
            <Button variant="outline" className="mt-4">Go to Classes</Button>
          </Link>
        </Card>
      ) : (
        <div className="space-y-4">
          {courses.map((c) => {
            const cGrades = grades.filter((g) => g.course_id === c.id);
            const cCats = categories.filter((cat) => cat.course_id === c.id);
            const result = calculateCourseGrade(c, cGrades, cCats);
            const colors = getCourseColor(c.color);

            return (
              <Card key={c.id} className={cn('p-5 border-l-4', colors.border)}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-lg">{c.name}</h3>
                    <p className="text-xs text-muted-foreground">{c.teacher || 'No teacher'} · {c.grading_system === 'weighted' ? 'Weighted' : 'Points-based'}</p>
                  </div>
                  {result.percentage > 0 && (
                    <div className="text-right">
                      <div className={cn('text-3xl font-bold', getLetterGradeColor(result.letterGrade))}>
                        {result.letterGrade}
                      </div>
                      <div className="text-sm text-muted-foreground">{result.percentage.toFixed(1)}%</div>
                    </div>
                  )}
                </div>

                {result.details.length > 0 && result.details[0].count > 0 && (
                  <div className="space-y-2">
                    {result.details.map((d, i) => (
                      <div key={i} className="flex items-center justify-between text-sm p-2 rounded-md bg-muted/50">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{d.categoryName}</span>
                          {d.weight !== 100 && <span className="text-xs text-muted-foreground">({d.weight}%)</span>}
                          <span className="text-xs text-muted-foreground">{d.count} assignment{d.count !== 1 ? 's' : ''}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-muted-foreground">{d.earned.toFixed(1)} / {d.possible.toFixed(1)}</span>
                          <span className="font-semibold">{d.percentage.toFixed(1)}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {cGrades.length > 0 && (
                  <div className="mt-4 pt-3 border-t">
                    <p className="text-xs font-medium text-muted-foreground uppercase mb-2">Recent Grades</p>
                    <div className="flex flex-wrap gap-2">
                      {cGrades.slice(-5).map((g) => (
                        <div key={g.id} className="text-xs px-2 py-1 rounded-md bg-muted">
                          {g.title}: {g.points_earned ?? '?'}/{g.points_possible}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex gap-2 mt-4 pt-3 border-t">
                  <Button size="sm" variant="outline" onClick={() => setSelectedCourse(c)}>
                    <Calculator className="w-3 h-3 mr-1" />
                    What-If Calculator
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {showAddGrade && (
        <AddGradeDialog
          open={showAddGrade}
          onClose={() => setShowAddGrade(false)}
          courses={courses}
          categories={categories}
          userId={user!.id}
          onAdded={() => { loadData(); }}
        />
      )}

      {selectedCourse && (
        <WhatIfDialog
          course={selectedCourse}
          grades={grades.filter((g) => g.course_id === selectedCourse.id)}
          categories={categories.filter((cat) => cat.course_id === selectedCourse.id)}
          onClose={() => setSelectedCourse(null)}
        />
      )}
    </div>
  );
}

function AddGradeDialog({ open, onClose, courses, categories, userId, onAdded }: {
  open: boolean;
  onClose: () => void;
  courses: Course[];
  categories: GradeCategory[];
  userId: string;
  onAdded: () => void;
}) {
  const [title, setTitle] = useState('');
  const [courseId, setCourseId] = useState(courses[0]?.id ?? '');
  const [earned, setEarned] = useState('');
  const [possible, setPossible] = useState('100');
  const [categoryId, setCategoryId] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) { toast.error('Title is required'); return; }
    if (!courseId) { toast.error('Select a class'); return; }
    setSaving(true);
    const { error } = await supabase.from('grades').insert({
      user_id: userId,
      course_id: courseId,
      category_id: categoryId || null,
      title,
      points_earned: earned ? parseFloat(earned) : null,
      points_possible: parseFloat(possible) || 100,
      status: 'graded',
      graded_date: new Date().toISOString().split('T')[0],
    });
    if (error) { toast.error('Failed to add grade'); setSaving(false); return; }
    toast.success('Grade added');
    onAdded();
    onClose();
    setTitle(''); setEarned('');
  };

  const courseCats = categories.filter((c) => c.course_id === courseId);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add Grade</DialogTitle>
          <DialogDescription>Enter a grade for one of your classes.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Chapter 3 Quiz" />
          </div>
          <div className="space-y-2">
            <Label>Class</Label>
            <Select value={courseId} onValueChange={setCourseId}>
              <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
              <SelectContent>
                {courses.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {courseCats.length > 0 && (
            <div className="space-y-2">
              <Label>Category (optional)</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger><SelectValue placeholder="No category" /></SelectTrigger>
                <SelectContent>
                  {courseCats.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} ({c.weight}%)</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Points Earned</Label>
              <Input type="number" value={earned} onChange={(e) => setEarned(e.target.value)} placeholder="45" />
            </div>
            <div className="space-y-2">
              <Label>Points Possible</Label>
              <Input type="number" value={possible} onChange={(e) => setPossible(e.target.value)} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Add'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function WhatIfDialog({ course, grades, categories, onClose }: {
  course: Course;
  grades: Grade[];
  categories: GradeCategory[];
  onClose: () => void;
}) {
  const [hypotheticals, setHypotheticals] = useState<WhatIfAssignment[]>([
    { categoryId: categories[0]?.id ?? null, pointsEarned: 85, pointsPossible: 100, title: 'Hypothetical Test' },
  ]);

  const result = calculateWhatIf(course, grades, categories, hypotheticals);

  const addHypothetical = () => {
    setHypotheticals([...hypotheticals, { categoryId: categories[0]?.id ?? null, pointsEarned: 90, pointsPossible: 100, title: `Hypothetical ${hypotheticals.length + 1}` }]);
  };

  const updateHypothetical = (index: number, field: keyof WhatIfAssignment, value: any) => {
    setHypotheticals(hypotheticals.map((h, i) => i === index ? { ...h, [field]: value } : h));
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>What-If Calculator — {course.name}</DialogTitle>
          <DialogDescription>See how hypothetical assignments affect your grade.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Current</p>
              <p className={cn('text-2xl font-bold', getLetterGradeColor(result.currentGrade.letterGrade))}>
                {result.currentGrade.percentage.toFixed(1)}%
              </p>
              <p className="text-xs">{result.currentGrade.letterGrade}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Projected</p>
              <p className={cn('text-2xl font-bold', getLetterGradeColor(result.projectedGrade.letterGrade))}>
                {result.projectedGrade.percentage.toFixed(1)}%
              </p>
              <p className="text-xs">{result.projectedGrade.letterGrade}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Change</p>
              <p className={cn('text-2xl font-bold', result.difference >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400')}>
                {result.difference >= 0 ? '+' : ''}{result.difference.toFixed(1)}%
              </p>
            </div>
          </div>

          {hypotheticals.map((h, i) => (
            <div key={i} className="p-3 rounded-lg border space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <Input value={h.title} onChange={(e) => updateHypothetical(i, 'title', e.target.value)} className="col-span-3" placeholder="Assignment name" />
                {categories.length > 0 && (
                  <Select value={h.categoryId ?? ''} onValueChange={(v) => updateHypothetical(i, 'categoryId', v || null)}>
                    <SelectTrigger className="col-span-3"><SelectValue placeholder="Category" /></SelectTrigger>
                    <SelectContent>
                      {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} ({c.weight}%)</SelectItem>)}
                    </SelectContent>
                  </Select>
                )}
                <div className="space-y-1">
                  <Label className="text-xs">Earned</Label>
                  <Input type="number" value={h.pointsEarned} onChange={(e) => updateHypothetical(i, 'pointsEarned', parseFloat(e.target.value) || 0)} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Possible</Label>
                  <Input type="number" value={h.pointsPossible} onChange={(e) => updateHypothetical(i, 'pointsPossible', parseFloat(e.target.value) || 100)} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Score</Label>
                  <div className="h-10 flex items-center justify-center rounded-md bg-muted text-sm font-semibold">
                    {((h.pointsEarned / h.pointsPossible) * 100).toFixed(0)}%
                  </div>
                </div>
              </div>
            </div>
          ))}

          <Button variant="outline" onClick={addHypothetical} className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Add Another Hypothetical
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
