'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabase/client';
import { toast } from 'sonner';
import { User, Bell, Plug, Palette, Shield, Download, Trash2, Calendar, GraduationCap, Sparkles, Clock } from 'lucide-react';
import { useState } from 'react';

export default function SettingsPage() {
  return (
    <AppShell>
      <SettingsContent />
    </AppShell>
  );
}

function SettingsContent() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [educationLevel, setEducationLevel] = useState(profile?.education_level ?? 'high-school');
  const [schoolName, setSchoolName] = useState(profile?.school_name ?? '');
  const [saving, setSaving] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  // Notification prefs (local state - would persist to DB)
  const [notifDueTomorrow, setNotifDueTomorrow] = useState(true);
  const [notifDueToday, setNotifDueToday] = useState(true);
  const [notifOverdue, setNotifOverdue] = useState(true);
  const [notifGradePosted, setNotifGradePosted] = useState(true);
  const [notifTestApproaching, setNotifTestApproaching] = useState(true);
  const [notifStudyReminder, setNotifStudyReminder] = useState(false);

  const handleSaveProfile = async () => {
    setSaving(true);
    const { error } = await supabase.from('profiles').update({
      full_name: fullName,
      education_level: educationLevel,
      school_name: schoolName,
    }).eq('id', user!.id);
    if (error) { toast.error('Failed to save profile'); setSaving(false); return; }
    await refreshProfile();
    toast.success('Profile updated');
    setSaving(false);
  };

  const handleExportData = async () => {
    if (!user) return;
    const [aRes, cRes, gRes] = await Promise.all([
      supabase.from('assignments').select('*').eq('user_id', user.id),
      supabase.from('courses').select('*').eq('user_id', user.id),
      supabase.from('grades').select('*').eq('user_id', user.id),
    ]);
    const exportData = {
      profile,
      courses: cRes.data,
      assignments: aRes.data,
      grades: gRes.data,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eduflow-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Data exported');
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    const { error } = await supabase.from('profiles').delete().eq('id', user.id);
    if (error) { toast.error('Failed to delete account'); return; }
    await signOut();
    toast.success('Account deleted');
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Settings</h2>
        <p className="text-sm text-muted-foreground">Manage your account and preferences</p>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        {/* Profile */}
        <TabsContent value="profile" className="space-y-4">
          <Card className="p-5 space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><User className="w-5 h-5 text-primary" /> Profile</h3>
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Education Level</Label>
              <Select value={educationLevel} onValueChange={setEducationLevel}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="middle-school">Middle School</SelectItem>
                  <SelectItem value="high-school">High School</SelectItem>
                  <SelectItem value="college">College</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>School Name</Label>
              <Input value={schoolName} onChange={(e) => setSchoolName(e.target.value)} placeholder="e.g., Lincoln High School" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input value={user?.email ?? ''} disabled className="bg-muted" />
            </div>
            <Button onClick={handleSaveProfile} disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</Button>
          </Card>

          <Card className="p-5 space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><GraduationCap className="w-5 h-5 text-primary" /> Grading Preferences</h3>
            <div className="space-y-2">
              <Label>Default Grading Scale</Label>
              <Select defaultValue="standard">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard (90=A, 80=B, 70=C, 60=D)</SelectItem>
                  <SelectItem value="plus-minus">With +/- (93=A, 90=A-, 87=B+...)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="space-y-4">
          <Card className="p-5 space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><Bell className="w-5 h-5 text-primary" /> Notification Preferences</h3>
            {[
              { label: 'Assignment due tomorrow', desc: 'Get notified the day before an assignment is due', state: notifDueTomorrow, setter: setNotifDueTomorrow },
              { label: 'Assignment due today', desc: 'Get notified on the day an assignment is due', state: notifDueToday, setter: setNotifDueToday },
              { label: 'Assignment overdue', desc: 'Get notified when an assignment becomes overdue', state: notifOverdue, setter: setNotifOverdue },
              { label: 'Grade posted', desc: 'Get notified when a new grade is entered', state: notifGradePosted, setter: setNotifGradePosted },
              { label: 'Test approaching', desc: 'Get notified a few days before a test', state: notifTestApproaching, setter: setNotifTestApproaching },
              { label: 'Study session reminder', desc: 'Get reminded about scheduled study sessions', state: notifStudyReminder, setter: setNotifStudyReminder },
            ].map((n, i) => (
              <div key={i}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{n.label}</p>
                    <p className="text-xs text-muted-foreground">{n.desc}</p>
                  </div>
                  <Switch checked={n.state} onCheckedChange={n.setter} />
                </div>
                {i < 5 && <Separator className="mt-4" />}
              </div>
            ))}
          </Card>
        </TabsContent>

        {/* Integrations */}
        <TabsContent value="integrations" className="space-y-4">
          <Card className="p-5 space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><Plug className="w-5 h-5 text-primary" /> Connected Integrations</h3>
            {[
              { name: 'Canvas LMS', desc: 'Sync courses, assignments, and grades from Canvas', status: 'Not connected', color: 'bg-red-500' },
              { name: 'Google Calendar', desc: 'Sync assignments and study sessions as events', status: 'Not connected', color: 'bg-blue-500' },
              { name: 'ClassLink', desc: 'Single sign-on for participating school districts', status: 'Not connected', color: 'bg-green-500' },
            ].map((int, i) => (
              <div key={i}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg ${int.color}/10 flex items-center justify-center`}>
                      <div className={`w-5 h-5 rounded ${int.color}`} />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{int.name}</p>
                      <p className="text-xs text-muted-foreground">{int.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{int.status}</span>
                    <Button size="sm" variant="outline">Connect</Button>
                  </div>
                </div>
                {i < 2 && <Separator className="mt-4" />}
              </div>
            ))}
            <p className="text-xs text-muted-foreground pt-2">
              Integrations are clearly labeled as demo or connected. EduFlow never asks for your school password.
            </p>
          </Card>
        </TabsContent>

        {/* Privacy */}
        <TabsContent value="privacy" className="space-y-4">
          <Card className="p-5 space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><Shield className="w-5 h-5 text-primary" /> Privacy & Data</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Export your data</p>
                  <p className="text-xs text-muted-foreground">Download all your EduFlow data as JSON</p>
                </div>
                <Button variant="outline" size="sm" onClick={handleExportData}>
                  <Download className="w-4 h-4 mr-1" />
                  Export
                </Button>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-destructive">Delete account</p>
                  <p className="text-xs text-muted-foreground">Permanently delete your account and all data</p>
                </div>
                <Button variant="destructive" size="sm" onClick={() => setShowDelete(true)}>
                  <Trash2 className="w-4 h-4 mr-1" />
                  Delete
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {showDelete && (
        <Dialog open onOpenChange={(o) => !o && setShowDelete(false)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Delete Account?</DialogTitle>
              <DialogDescription>
                This will permanently delete your account, all classes, assignments, grades, and settings. This cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDelete(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleDeleteAccount}>Delete Forever</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
