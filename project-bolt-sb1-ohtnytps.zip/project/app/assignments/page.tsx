'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Assignment, Course, Subtask } from '@/lib/types';
import { AssignmentCard } from '@/components/shared/assignment-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { isDueToday, isDueThisWeek, isOverdue, formatDueLabel, formatDuration, getCourseColor } from '@/lib/date-utils';
import { Plus, ClipboardList, X, Trash2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';

type ViewFilter = 'all' | 'today' | 'upcoming' | 'overdue' | 'completed';
type SortBy = 'dueDate' | 'priority' | 'class' | 'estimated' | 'status';

export default function AssignmentsPage() {
  return (
    <AppShell>
      <AssignmentsContent />
    </AppShell>
  );
}

function AssignmentsContent() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [subtasks, setSubtasks] = useState<Record<string, Subtask[]>>({});
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewFilter>('all');
  const [sortBy, setSortBy] = useState<SortBy>('dueDate');
  const [filterCourse, setFilterCourse] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [aRes, cRes] = await Promise.all([
        supabase.from('assignments').select('*').eq('user_id', user.id).order('due_date'),
        supabase.from('courses').select('*').eq('user_id', user.id),
      ]);
      setAssignments((aRes.data as Assignment[]) ?? []);
      setCourses((cRes.data as Course[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  useEffect(() => {
    if (selectedAssignment) {
      supabase.from('subtasks').select('*').eq('assignment_id', selectedAssignment.id).order('sort_order')
        .then(({ data }) => setSubtasks((prev) => ({ ...prev, [selectedAssignment.id]: data ?? [] })));
    }
  }, [selectedAssignment]);

  const filtered = useMemo(() => {
    let result = [...assignments];

    if (view === 'today') result = result.filter((a) => isDueToday(a.due_date) && a.status !== 'completed');
    else if (view === 'upcoming') result = result.filter((a) => isDueThisWeek(a.due_date) && a.status !== 'completed');
    else if (view === 'overdue') result = result.filter((a) => isOverdue(a.due_date, a.status));
    else if (view === 'completed') result = result.filter((a) => a.status === 'completed');

    if (filterCourse !== 'all') result = result.filter((a) => a.course_id === filterCourse);
    if (search) result = result.filter((a) => a.title.toLowerCase().includes(search.toLowerCase()));

    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    const statusOrder = { overdue: 0, 'not-started': 1, 'in-progress': 2, completed: 3 };

    result.sort((a, b) => {
      switch (sortBy) {
        case 'dueDate': return (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999');
        case 'priority': return priorityOrder[a.priority] - priorityOrder[b.priority];
        case 'class': return (courses.find((c) => c.id === a.course_id)?.name ?? '').localeCompare(courses.find((c) => c.id === b.course_id)?.name ?? '');
        case 'estimated': return a.estimated_minutes - b.estimated_minutes;
        case 'status': return statusOrder[a.status] - statusOrder[b.status];
        default: return 0;
      }
    });

    return result;
  }, [assignments, view, sortBy, filterCourse, search, courses]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Assignments</h2>
          <p className="text-sm text-muted-foreground">{filtered.length} assignment{filtered.length !== 1 ? 's' : ''}</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Assignment
        </Button>
      </div>

      {/* Filters */}
      <div className="space-y-3">
        <Tabs value={view} onValueChange={(v) => setView(v as ViewFilter)}>
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="overdue">Overdue</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-3 flex-wrap">
          <Input
            placeholder="Search assignments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xs"
          />
          <Select value={filterCourse} onValueChange={setFilterCourse}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Filter by class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All classes</SelectItem>
              {courses.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortBy)}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dueDate">Due date</SelectItem>
              <SelectItem value="priority">Priority</SelectItem>
              <SelectItem value="class">Class</SelectItem>
              <SelectItem value="estimated">Est. time</SelectItem>
              <SelectItem value="status">Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Assignment list */}
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center">
          <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-lg">No assignments here</h3>
          <p className="text-sm text-muted-foreground mt-1">
            {assignments.length === 0
              ? 'Add your first assignment to get started.'
              : 'No assignments match your current filters.'}
          </p>
          {assignments.length === 0 && (
            <Button onClick={() => setShowAdd(true)} className="mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Add Assignment
            </Button>
          )}
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((a) => (
            <AssignmentCard
              key={a.id}
              assignment={a}
              course={courses.find((c) => c.id === a.course_id)}
              onNavigate={(id) => setSelectedAssignment(assignments.find((a) => a.id === id) ?? null)}
            />
          ))}
        </div>
      )}

      {/* Add Assignment Dialog */}
      {showAdd && (
        <AddAssignmentDialog
          open={showAdd}
          onClose={() => setShowAdd(false)}
          courses={courses}
          userId={user!.id}
          onAdded={(a) => { setAssignments((prev) => [a, ...prev]); }}
        />
      )}

      {/* Assignment Detail Dialog */}
      {selectedAssignment && (
        <AssignmentDetailDialog
          assignment={selectedAssignment}
          course={courses.find((c) => c.id === selectedAssignment.course_id)}
          subtasks={subtasks[selectedAssignment.id] ?? []}
          onClose={() => setSelectedAssignment(null)}
          onSubtaskToggle={(id, completed) => {
            setSubtasks((prev) => ({
              ...prev,
              [selectedAssignment.id]: (prev[selectedAssignment.id] ?? []).map((s) => s.id === id ? { ...s, completed } : s),
            }));
          }}
          onSubtaskAdd={(title) => {
            supabase.from('subtasks').insert({
              assignment_id: selectedAssignment.id,
              title,
              sort_order: (subtasks[selectedAssignment.id] ?? []).length,
            }).select().single().then(({ data }) => {
              if (data) {
                setSubtasks((prev) => ({
                  ...prev,
                  [selectedAssignment.id]: [...(prev[selectedAssignment.id] ?? []), data as Subtask],
                }));
              }
            });
          }}
          onDelete={async () => {
            await supabase.from('assignments').delete().eq('id', selectedAssignment.id);
            setAssignments((prev) => prev.filter((a) => a.id !== selectedAssignment.id));
            setSelectedAssignment(null);
            toast.success('Assignment deleted');
          }}
        />
      )}
    </div>
  );
}

function AddAssignmentDialog({ open, onClose, courses, userId, onAdded }: {
  open: boolean;
  onClose: () => void;
  courses: Course[];
  userId: string;
  onAdded: (a: Assignment) => void;
}) {
  const [title, setTitle] = useState('');
  const [courseId, setCourseId] = useState(courses[0]?.id ?? '');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('11:59 PM');
  const [priority, setPriority] = useState('medium');
  const [estimated, setEstimated] = useState('30');
  const [points, setPoints] = useState('100');
  const [type, setType] = useState('homework');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) { toast.error('Title is required'); return; }
    setSaving(true);
    const { data, error } = await supabase.from('assignments').insert({
      user_id: userId,
      title,
      course_id: courseId || null,
      due_date: dueDate || null,
      due_time: dueTime,
      priority,
      estimated_minutes: parseInt(estimated) || 30,
      points_possible: parseFloat(points) || 100,
      assignment_type: type,
      description,
    }).select().single();

    if (error) {
      toast.error('Failed to create assignment');
      setSaving(false);
      return;
    }
    onAdded(data as Assignment);
    toast.success('Assignment created');
    onClose();
    setTitle(''); setDescription(''); setDueDate('');
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Assignment</DialogTitle>
          <DialogDescription>Create a new assignment for your classes.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Chapter 5 Homework" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Class</Label>
              <Select value={courseId} onValueChange={setCourseId}>
                <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
                <SelectContent>
                  {courses.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="homework">Homework</SelectItem>
                  <SelectItem value="quiz">Quiz</SelectItem>
                  <SelectItem value="test">Test</SelectItem>
                  <SelectItem value="project">Project</SelectItem>
                  <SelectItem value="essay">Essay</SelectItem>
                  <SelectItem value="lab">Lab</SelectItem>
                  <SelectItem value="presentation">Presentation</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Due Date</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Due Time</Label>
              <Input value={dueTime} onChange={(e) => setDueTime(e.target.value)} placeholder="11:59 PM" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-2">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Est. Minutes</Label>
              <Input type="number" value={estimated} onChange={(e) => setEstimated(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Points</Label>
              <Input type="number" value={points} onChange={(e) => setPoints(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Optional notes..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Create'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AssignmentDetailDialog({ assignment, course, subtasks, onClose, onSubtaskToggle, onSubtaskAdd, onDelete }: {
  assignment: Assignment;
  course?: Course;
  subtasks: Subtask[];
  onClose: () => void;
  onSubtaskToggle: (id: string, completed: boolean) => void;
  onSubtaskAdd: (title: string) => void;
  onDelete: () => void;
}) {
  const [newSubtask, setNewSubtask] = useState('');
  const courseColor = course ? getCourseColor(course.color) : getCourseColor('blue');

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            {course && (
              <span className={cn('text-xs font-medium px-2 py-0.5 rounded-md', courseColor.bg, courseColor.text)}>
                {course.name}
              </span>
            )}
            <span className="text-xs text-muted-foreground capitalize">{assignment.assignment_type}</span>
          </div>
          <DialogTitle className="text-xl">{assignment.title}</DialogTitle>
          <DialogDescription>{formatDueLabel(assignment.due_date, assignment.due_time)} · {formatDuration(assignment.estimated_minutes)}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {assignment.description && (
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase mb-1">Description</p>
              <p className="text-sm">{assignment.description}</p>
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-2 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Priority</p>
              <p className="font-semibold capitalize text-sm">{assignment.priority}</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Points</p>
              <p className="font-semibold text-sm">{assignment.points_possible}</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Status</p>
              <p className="font-semibold capitalize text-sm">{assignment.status.replace('-', ' ')}</p>
            </div>
          </div>

          {/* Subtasks */}
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase">Subtasks</p>
            {subtasks.map((s) => (
              <div key={s.id} className="flex items-center gap-2">
                <Checkbox checked={s.completed} onCheckedChange={(c) => onSubtaskToggle(s.id, !!c)} />
                <span className={cn('text-sm', s.completed && 'line-through text-muted-foreground')}>{s.title}</span>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <Input
                value={newSubtask}
                onChange={(e) => setNewSubtask(e.target.value)}
                placeholder="Add a subtask..."
                className="h-8 text-sm"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newSubtask.trim()) {
                    onSubtaskAdd(newSubtask.trim());
                    setNewSubtask('');
                  }
                }}
              />
              <Button size="sm" variant="ghost" onClick={() => {
                if (newSubtask.trim()) { onSubtaskAdd(newSubtask.trim()); setNewSubtask(''); }
              }}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {assignment.notes && (
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase mb-1">Notes</p>
              <p className="text-sm">{assignment.notes}</p>
            </div>
          )}

          <div className="flex items-center gap-2 pt-2 border-t">
            <Link href={`/ai?assignment=${assignment.id}`}>
              <Button size="sm" variant="default">
                <Sparkles className="w-3 h-3 mr-1" />
                Get Help
              </Button>
            </Link>
            {assignment.lms_link && (
              <a href={assignment.lms_link} target="_blank" rel="noopener noreferrer">
                <Button size="sm" variant="outline">Open in Canvas</Button>
              </a>
            )}
            <Button size="sm" variant="ghost" className="text-destructive ml-auto" onClick={onDelete}>
              <Trash2 className="w-3 h-3 mr-1" />
              Delete
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
