'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Assignment, Course, Grade, GradeCategory } from '@/lib/types';
import { StatCard } from '@/components/shared/stat-card';
import { AssignmentCard } from '@/components/shared/assignment-card';
import { CourseCard } from '@/components/shared/course-card';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, ClipboardList, Calendar, CheckCircle2, AlertCircle, Clock, TrendingUp, GraduationCap } from 'lucide-react';
import { getGreeting, isDueToday, isDueThisWeek, isOverdue } from '@/lib/date-utils';
import { calculateCourseGrade, calculateGPA, getLetterGrade } from '@/lib/grading';
import Link from 'next/link';
import { format } from 'date-fns';

export default function DashboardPage() {
  return (
    <AppShell>
      <DashboardContent />
    </AppShell>
  );
}

function DashboardContent() {
  const { user, profile } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [categories, setCategories] = useState<GradeCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [aRes, cRes, gRes, catRes] = await Promise.all([
        supabase.from('assignments').select('*').eq('user_id', user.id).order('due_date'),
        supabase.from('courses').select('*').eq('user_id', user.id),
        supabase.from('grades').select('*').eq('user_id', user.id),
        supabase.from('grade_categories').select('*, course:courses(id)').then(({ data }) => {
          return { data: data?.filter((c: any) => c.course?.user_id === user.id) ?? [], error: null };
        }),
      ]);

      setAssignments((aRes.data as Assignment[]) ?? []);
      setCourses((cRes.data as Course[]) ?? []);
      setGrades((gRes.data as Grade[]) ?? []);
      setCategories((catRes.data as GradeCategory[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  const dueToday = assignments.filter((a) => isDueToday(a.due_date) && a.status !== 'completed');
  const dueThisWeek = assignments.filter((a) => isDueThisWeek(a.due_date) && a.status !== 'completed');
  const overdue = assignments.filter((a) => isOverdue(a.due_date, a.status));
  const completed = assignments.filter((a) => a.status === 'completed');

  const courseGrades = courses.map((c) => {
    const cGrades = grades.filter((g) => g.course_id === c.id);
    const cCats = categories.filter((cat) => cat.course_id === c.id);
    return calculateCourseGrade(c, cGrades, cCats);
  });
  const avgGrade = courseGrades.length > 0
    ? courseGrades.reduce((s, g) => s + g.percentage, 0) / courseGrades.length
    : 0;
  const gpa = calculateGPA(courseGrades.map((g) => ({ percentage: g.percentage, isWeighted: false, weight: 1 })));

  const todayWork = [...dueToday, ...overdue].slice(0, 6);

  // Recommendation logic
  const nextDue = assignments
    .filter((a) => a.status !== 'completed')
    .sort((a, b) => (a.due_date ?? '9999').localeCompare(b.due_date ?? '9999'))[0];

  const greeting = getGreeting();
  const firstName = (profile?.full_name || user?.email?.split('@')[0] || 'Student').split(' ')[0];

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-24 bg-muted rounded-xl" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-24 bg-muted rounded-xl" />
          ))}
        </div>
        <div className="h-64 bg-muted rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Greeting */}
      <div className="space-y-1">
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
          {greeting}, {firstName}.
        </h2>
        <p className="text-muted-foreground">Let's keep your schoolwork flowing.</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Due Today" value={dueToday.length} icon={Clock} variant={dueToday.length > 0 ? 'warning' : 'success'} />
        <StatCard label="This Week" value={dueThisWeek.length} icon={Calendar} variant="info" />
        <StatCard label="Overdue" value={overdue.length} icon={AlertCircle} variant={overdue.length > 0 ? 'danger' : 'success'} />
        <StatCard label="Completed" value={completed.length} icon={CheckCircle2} variant="success" />
        <StatCard label="Avg Grade" value={avgGrade > 0 ? `${avgGrade.toFixed(1)}%` : '—'} icon={TrendingUp} variant="info" />
        <StatCard label="GPA" value={gpa.unweighted > 0 ? gpa.unweighted.toFixed(2) : '—'} icon={GraduationCap} variant="info" />
      </div>

      {/* Recommendation */}
      {nextDue && (
        <Card className="p-4 border-l-4 border-l-primary bg-primary/5">
          <div className="flex items-start gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-primary uppercase tracking-wide">EduFlow Recommendation</p>
              <p className="text-sm mt-1">
                {overdue.length > 0
                  ? `You have ${overdue.length} overdue assignment${overdue.length > 1 ? 's' : ''}. Start with "${overdue[0].title}" — it's past due.`
                  : dueToday.length > 0
                  ? `You have ${dueToday.length} assignment${dueToday.length > 1 ? 's' : ''} due today. Start with "${dueToday[0].title}" — it's due first.`
                  : `You have ${nextDue.estimated_minutes} minutes of work for "${nextDue.title}". Due ${nextDue.due_date ? format(new Date(nextDue.due_date), 'MMM d') : 'soon'}.`}
              </p>
              <div className="flex gap-2 mt-3">
                <Link href="/planner">
                  <Button size="sm" variant="default" className="h-8 text-xs">
                    View Plan
                  </Button>
                </Link>
                <Link href="/assignments">
                  <Button size="sm" variant="outline" className="h-8 text-xs">
                    All Assignments
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </Card>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Today's Work */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Today's Work</h3>
            <Link href="/assignments">
              <Button variant="ghost" size="sm" className="text-xs">View all</Button>
            </Link>
          </div>

          {todayWork.length === 0 ? (
            <Card className="p-8 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
              <p className="font-medium">You're all caught up!</p>
              <p className="text-sm text-muted-foreground mt-1">No assignments due today. Great work.</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {todayWork.map((a) => (
                <AssignmentCard
                  key={a.id}
                  assignment={a}
                  course={courses.find((c) => c.id === a.course_id)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Classes overview */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Your Classes</h3>
            <Link href="/classes">
              <Button variant="ghost" size="sm" className="text-xs">View all</Button>
            </Link>
          </div>

          {courses.length === 0 ? (
            <Card className="p-6 text-center">
              <ClipboardList className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No classes yet.</p>
              <Link href="/classes">
                <Button size="sm" variant="outline" className="mt-3">Add a class</Button>
              </Link>
            </Card>
          ) : (
            <div className="space-y-2">
              {courses.slice(0, 4).map((c) => {
                const cGrades = grades.filter((g) => g.course_id === c.id);
                const cCats = categories.filter((cat) => cat.course_id === c.id);
                const result = calculateCourseGrade(c, cGrades, cCats);
                const upcoming = assignments.filter((a) => a.course_id === c.id && a.status !== 'completed').length;
                return (
                  <CourseCard
                    key={c.id}
                    course={c}
                    currentGrade={result.percentage > 0 ? getLetterGrade(result.percentage) : undefined}
                    upcomingCount={upcoming}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
