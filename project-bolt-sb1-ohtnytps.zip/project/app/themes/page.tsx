'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useTheme, THEME_PRESETS, ACCENT_COLORS } from '@/lib/theme-context';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Check, Sun, Moon, Monitor, Palette } from 'lucide-react';
import type { AccentColor, ThemeMode } from '@/lib/types';
import { toast } from 'sonner';

export default function ThemesPage() {
  return (
    <AppShell>
      <ThemesContent />
    </AppShell>
  );
}

function ThemesContent() {
  const { preset, mode, accent, setPreset, setMode, setAccent } = useTheme();

  const modeOptions: { id: ThemeMode; label: string; icon: any }[] = [
    { id: 'light', label: 'Light', icon: Sun },
    { id: 'dark', label: 'Dark', icon: Moon },
    { id: 'system', label: 'System', icon: Monitor },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Themes</h2>
        <p className="text-sm text-muted-foreground">Make EduFlow yours with custom themes and accent colors</p>
      </div>

      {/* Mode selector */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4">Appearance</h3>
        <div className="grid grid-cols-3 gap-3">
          {modeOptions.map((m) => (
            <button
              key={m.id}
              onClick={() => { setMode(m.id); toast.success(`Theme set to ${m.label}`); }}
              className={cn(
                'flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all',
                mode === m.id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted'
              )}
            >
              <m.icon className="w-6 h-6" />
              <span className="text-sm font-medium">{m.label}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Preset themes */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Palette className="w-5 h-5 text-primary" />
          Preset Themes
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {THEME_PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => { setPreset(p.id); toast.success(`Theme: ${p.name}`); }}
              className={cn(
                'relative p-3 rounded-lg border-2 transition-all text-left',
                preset === p.id ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-primary/50'
              )}
            >
              <div className="flex gap-1 mb-2">
                <div className="w-6 h-6 rounded-md border" style={{ background: `hsl(${p.vars['--background']})` }} />
                <div className="w-6 h-6 rounded-md border" style={{ background: `hsl(${p.vars['--card']})` }} />
                <div className="w-6 h-6 rounded-md" style={{ background: `hsl(${p.vars['--primary']})` }} />
              </div>
              <p className="text-sm font-semibold">{p.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{p.mode}</p>
              {preset === p.id && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                  <Check className="w-3 h-3 text-primary-foreground" />
                </div>
              )}
            </button>
          ))}
        </div>
      </Card>

      {/* Accent colors */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4">Accent Color</h3>
        <div className="flex flex-wrap gap-3">
          {(Object.keys(ACCENT_COLORS) as AccentColor[]).map((c) => (
            <button
              key={c}
              onClick={() => { setAccent(c); toast.success(`Accent: ${c}`); }}
              className={cn(
                'w-12 h-12 rounded-full border-2 transition-all relative',
                accent === c ? 'border-foreground scale-110' : 'border-transparent hover:scale-105'
              )}
              style={{ background: `hsl(${ACCENT_COLORS[c]})` }}
              title={c}
            >
              {accent === c && (
                <Check className="absolute inset-0 m-auto w-5 h-5 text-white" />
              )}
            </button>
          ))}
        </div>
      </Card>

      {/* Preview */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4">Preview</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="p-4 rounded-lg bg-background border">
            <p className="text-xs text-muted-foreground mb-1">Background</p>
            <p className="text-sm font-medium text-foreground">Text on background</p>
          </div>
          <div className="p-4 rounded-lg bg-primary text-primary-foreground">
            <p className="text-xs opacity-80 mb-1">Primary</p>
            <p className="text-sm font-medium">Text on primary</p>
          </div>
          <div className="p-4 rounded-lg bg-muted">
            <p className="text-xs text-muted-foreground mb-1">Muted</p>
            <p className="text-sm font-medium text-foreground">Text on muted</p>
          </div>
          <div className="p-4 rounded-lg bg-card border">
            <p className="text-xs text-muted-foreground mb-1">Card</p>
            <p className="text-sm font-medium text-foreground">Text on card</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
