'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Assignment, Course, CalendarEvent, StudySession } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { getCourseColor } from '@/lib/date-utils';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, startOfWeek, endOfWeek, parseISO } from 'date-fns';
import { Plus, Calendar as CalIcon, ChevronLeft, ChevronRight, Clock, MapPin } from 'lucide-react';
import { toast } from 'sonner';

type ViewMode = 'month' | 'week' | 'agenda';

export default function CalendarPage() {
  return (
    <AppShell>
      <CalendarContent />
    </AppShell>
  );
}

function CalendarContent() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewMode>('month');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [aRes, cRes, eRes, sRes] = await Promise.all([
        supabase.from('assignments').select('*').eq('user_id', user.id),
        supabase.from('courses').select('*').eq('user_id', user.id),
        supabase.from('calendar_events').select('*').eq('user_id', user.id),
        supabase.from('study_sessions').select('*').eq('user_id', user.id),
      ]);
      setAssignments((aRes.data as Assignment[]) ?? []);
      setCourses((cRes.data as Course[]) ?? []);
      setEvents((eRes.data as CalendarEvent[]) ?? []);
      setStudySessions((sRes.data as StudySession[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  const allEvents = useMemo(() => {
    const items: { date: Date; title: string; type: string; color: string; time?: string; location?: string }[] = [];

    assignments.forEach((a) => {
      if (a.due_date) {
        const course = courses.find((c) => c.id === a.course_id);
        items.push({
          date: parseISO(a.due_date),
          title: a.title,
          type: a.assignment_type === 'test' ? 'test' : 'assignment',
          color: course ? getCourseColor(course.color).dot : 'bg-blue-500',
          time: a.due_time,
        });
      }
    });

    events.forEach((e) => {
      items.push({
        date: parseISO(e.event_date),
        title: e.title,
        type: e.event_type,
        color: e.event_type === 'personal' ? 'bg-emerald-500' : 'bg-blue-500',
        time: e.start_time ?? undefined,
        location: e.location || undefined,
      });
    });

    studySessions.forEach((s) => {
      items.push({
        date: parseISO(s.session_date),
        title: s.title,
        type: 'study',
        color: 'bg-amber-500',
        time: s.start_time ?? undefined,
      });
    });

    return items.sort((a, b) => a.date.getTime() - b.date.getTime());
  }, [assignments, courses, events, studySessions]);

  const getEventsForDay = (day: Date) => allEvents.filter((e) => isSameDay(e.date, day));

  if (loading) {
    return (
      <div className="space-y-4 max-w-7xl mx-auto">
        <div className="h-16 bg-muted rounded-lg animate-pulse" />
        <div className="h-96 bg-muted rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Calendar</h2>
          <p className="text-sm text-muted-foreground">All your deadlines and events in one place</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Event
        </Button>
      </div>

      <div className="flex items-center justify-between gap-4 flex-wrap">
        <Tabs value={view} onValueChange={(v) => setView(v as ViewMode)}>
          <TabsList>
            <TabsTrigger value="month">Month</TabsTrigger>
            <TabsTrigger value="week">Week</TabsTrigger>
            <TabsTrigger value="agenda">Agenda</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setCurrentDate(addMonths(currentDate, -1))}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-sm font-semibold min-w-[120px] text-center">
            {view === 'month' ? format(currentDate, 'MMMM yyyy') : format(currentDate, 'MMM d, yyyy')}
          </span>
          <Button variant="outline" size="icon" onClick={() => setCurrentDate(addMonths(currentDate, 1))}>
            <ChevronRight className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setCurrentDate(new Date())}>Today</Button>
        </div>
      </div>

      {view === 'month' && (
        <MonthView currentDate={currentDate} getEventsForDay={getEventsForDay} />
      )}
      {view === 'week' && (
        <WeekView currentDate={currentDate} getEventsForDay={getEventsForDay} />
      )}
      {view === 'agenda' && (
        <AgendaView allEvents={allEvents} />
      )}

      {showAdd && (
        <AddEventDialog
          open={showAdd}
          onClose={() => setShowAdd(false)}
          userId={user!.id}
          courses={courses}
          onAdded={() => {
            if (user) {
              supabase.from('calendar_events').select('*').eq('user_id', user.id).then(({ data }) => setEvents((data as CalendarEvent[]) ?? []));
            }
          }}
        />
      )}
    </div>
  );
}

function MonthView({ currentDate, getEventsForDay }: { currentDate: Date; getEventsForDay: (d: Date) => any[] }) {
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  return (
    <Card className="p-4">
      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
          <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map((day) => {
          const dayEvents = getEventsForDay(day);
          const inMonth = isSameMonth(day, currentDate);
          const today = isSameDay(day, new Date());
          return (
            <div
              key={day.toISOString()}
              className={cn(
                'min-h-[80px] md:min-h-[100px] p-1.5 rounded-md border transition-colors',
                inMonth ? 'bg-card' : 'bg-muted/30',
                today && 'border-primary border-2',
                !today && 'border-border'
              )}
            >
              <div className={cn('text-xs mb-1', inMonth ? 'text-foreground' : 'text-muted-foreground', today && 'font-bold text-primary')}>
                {format(day, 'd')}
              </div>
              <div className="space-y-1">
                {dayEvents.slice(0, 3).map((e: any, i: number) => (
                  <div key={i} className={cn('text-[10px] px-1.5 py-0.5 rounded truncate', `${e.color}/10`)}>
                    <span className={cn('inline-block w-1.5 h-1.5 rounded-full mr-1', e.color)} />
                    {e.title}
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <div className="text-[10px] text-muted-foreground px-1">+{dayEvents.length - 3} more</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function WeekView({ currentDate, getEventsForDay }: { currentDate: Date; getEventsForDay: (d: Date) => any[] }) {
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 0 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 0 });
  const days = eachDayOfInterval({ start: weekStart, end: weekEnd });

  return (
    <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
      {days.map((day) => {
        const dayEvents = getEventsForDay(day);
        const today = isSameDay(day, new Date());
        return (
          <Card key={day.toISOString()} className={cn('p-3 min-h-[200px]', today && 'border-primary border-2')}>
            <div className={cn('text-sm font-semibold mb-2', today && 'text-primary')}>
              {format(day, 'EEE d')}
            </div>
            <div className="space-y-2">
              {dayEvents.length === 0 ? (
                <p className="text-xs text-muted-foreground">No events</p>
              ) : (
                dayEvents.map((e: any, i: number) => (
                  <div key={i} className="text-xs p-2 rounded-md bg-muted/50">
                    <div className="flex items-center gap-1 mb-0.5">
                      <span className={cn('w-2 h-2 rounded-full', e.color)} />
                      <span className="font-medium truncate">{e.title}</span>
                    </div>
                    {e.time && <div className="flex items-center gap-1 text-muted-foreground"><Clock className="w-3 h-3" />{e.time}</div>}
                    {e.location && <div className="flex items-center gap-1 text-muted-foreground"><MapPin className="w-3 h-3" />{e.location}</div>}
                  </div>
                ))
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

function AgendaView({ allEvents }: { allEvents: { date: Date; title: string; type: string; color: string; time?: string; location?: string }[] }) {
  const upcoming = allEvents.filter((e) => e.date >= new Date(new Date().setHours(0, 0, 0, 0)));

  if (upcoming.length === 0) {
    return (
      <Card className="p-12 text-center">
        <CalIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="font-semibold text-lg">Your calendar is clear</h3>
        <p className="text-sm text-muted-foreground mt-1">No upcoming events. Enjoy the breather!</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {upcoming.map((e, i) => (
        <Card key={i} className="p-3 flex items-center gap-3">
          <div className="text-center min-w-[60px]">
            <p className="text-xs text-muted-foreground">{format(e.date, 'EEE')}</p>
            <p className="text-xl font-bold">{format(e.date, 'd')}</p>
            <p className="text-xs text-muted-foreground">{format(e.date, 'MMM')}</p>
          </div>
          <div className={cn('w-1 h-12 rounded-full', e.color)} />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm truncate">{e.title}</p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
              <span className="capitalize">{e.type}</span>
              {e.time && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{e.time}</span>}
              {e.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{e.location}</span>}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function AddEventDialog({ open, onClose, userId, courses, onAdded }: {
  open: boolean;
  onClose: () => void;
  userId: string;
  courses: Course[];
  onAdded: () => void;
}) {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [type, setType] = useState('personal');
  const [location, setLocation] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) { toast.error('Title is required'); return; }
    if (!date) { toast.error('Date is required'); return; }
    setSaving(true);
    const { error } = await supabase.from('calendar_events').insert({
      user_id: userId,
      title,
      event_date: date,
      start_time: time || null,
      event_type: type,
      location,
    });
    if (error) { toast.error('Failed to add event'); setSaving(false); return; }
    toast.success('Event added');
    onAdded();
    onClose();
    setTitle(''); setDate(''); setTime(''); setLocation('');
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add Event</DialogTitle>
          <DialogDescription>Add a personal event to your calendar.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Science Club Meeting" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Time</Label>
              <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="personal">Personal</SelectItem>
                <SelectItem value="study">Study Session</SelectItem>
                <SelectItem value="project">Project</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Location</Label>
            <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Optional" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Add'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
