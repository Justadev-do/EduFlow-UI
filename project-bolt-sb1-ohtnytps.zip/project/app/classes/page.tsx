'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Course, Assignment, Grade, GradeCategory } from '@/lib/types';
import { CourseCard } from '@/components/shared/course-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { calculateCourseGrade, getLetterGrade } from '@/lib/grading';
import { getLetterGradeColor } from '@/lib/course-utils';
import { Plus, BookOpen } from 'lucide-react';
import { toast } from 'sonner';
import * as LucideIcons from 'lucide-react';
import { cn } from '@/lib/utils';

const COURSE_COLOR_OPTIONS = ['blue', 'green', 'orange', 'red', 'purple', 'teal', 'amber', 'rose', 'cyan', 'indigo'];
const ICON_OPTIONS = ['BookOpen', 'Calculator', 'FlaskConical', 'Globe', 'Palette', 'Music', 'Code', 'Brain', 'Atom', 'Languages'];

export default function ClassesPage() {
  return (
    <AppShell>
      <ClassesContent />
    </AppShell>
  );
}

function ClassesContent() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [categories, setCategories] = useState<GradeCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  const loadData = async () => {
    if (!user) return;
    const [cRes, aRes, gRes] = await Promise.all([
      supabase.from('courses').select('*').eq('user_id', user.id),
      supabase.from('assignments').select('*').eq('user_id', user.id),
      supabase.from('grades').select('*').eq('user_id', user.id),
    ]);
    setCourses((cRes.data as Course[]) ?? []);
    setAssignments((aRes.data as Assignment[]) ?? []);
    setGrades((gRes.data as Grade[]) ?? []);

    const catPromises = ((cRes.data as Course[]) ?? []).map((c) =>
      supabase.from('grade_categories').select('*').eq('course_id', c.id)
    );
    const catResults = await Promise.all(catPromises);
    setCategories(catResults.flatMap((r) => (r.data as GradeCategory[]) ?? []));
    setLoading(false);
  };

  useEffect(() => { loadData(); }, [user]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Classes</h2>
          <p className="text-sm text-muted-foreground">{courses.length} class{courses.length !== 1 ? 'es' : ''}</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Class
        </Button>
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      ) : courses.length === 0 ? (
        <Card className="p-12 text-center">
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-lg">No classes yet</h3>
          <p className="text-sm text-muted-foreground mt-1">Add your classes to start organizing your schoolwork.</p>
          <Button onClick={() => setShowAdd(true)} className="mt-4">
            <Plus className="w-4 h-4 mr-2" />
            Add Class
          </Button>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((c) => {
            const cGrades = grades.filter((g) => g.course_id === c.id);
            const cCats = categories.filter((cat) => cat.course_id === c.id);
            const result = calculateCourseGrade(c, cGrades, cCats);
            const upcoming = assignments.filter((a) => a.course_id === c.id && a.status !== 'completed').length;
            return (
              <CourseCard
                key={c.id}
                course={c}
                currentGrade={result.percentage > 0 ? getLetterGrade(result.percentage) : undefined}
                upcomingCount={upcoming}
              />
            );
          })}
        </div>
      )}

      {showAdd && (
        <AddClassDialog
          open={showAdd}
          onClose={() => setShowAdd(false)}
          userId={user!.id}
          onAdded={() => { loadData(); }}
        />
      )}
    </div>
  );
}

function AddClassDialog({ open, onClose, userId, onAdded }: {
  open: boolean;
  onClose: () => void;
  userId: string;
  onAdded: () => void;
}) {
  const [name, setName] = useState('');
  const [teacher, setTeacher] = useState('');
  const [color, setColor] = useState('blue');
  const [icon, setIcon] = useState('BookOpen');
  const [period, setPeriod] = useState('');
  const [room, setRoom] = useState('');
  const [gradingSystem, setGradingSystem] = useState('points');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!name.trim()) { toast.error('Class name is required'); return; }
    setSaving(true);
    const { error } = await supabase.from('courses').insert({
      user_id: userId,
      name,
      teacher,
      color,
      icon,
      period,
      room,
      grading_system: gradingSystem,
    });
    if (error) {
      toast.error('Failed to create class');
      setSaving(false);
      return;
    }
    toast.success('Class created');
    onAdded();
    onClose();
    setName(''); setTeacher(''); setPeriod(''); setRoom('');
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Class</DialogTitle>
          <DialogDescription>Create a new class to organize assignments and grades.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Class Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Algebra II" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Teacher</Label>
              <Input value={teacher} onChange={(e) => setTeacher(e.target.value)} placeholder="Mr. Smith" />
            </div>
            <div className="space-y-2">
              <Label>Period</Label>
              <Input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="Period 3" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Room</Label>
              <Input value={room} onChange={(e) => setRoom(e.target.value)} placeholder="Room 204" />
            </div>
            <div className="space-y-2">
              <Label>Grading System</Label>
              <Select value={gradingSystem} onValueChange={setGradingSystem}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="points">Points-based</SelectItem>
                  <SelectItem value="weighted">Weighted Categories</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Color</Label>
            <div className="flex flex-wrap gap-2">
              {COURSE_COLOR_OPTIONS.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={cn('w-8 h-8 rounded-lg border-2 transition-all', `bg-${c}-500`, color === c ? 'border-foreground scale-110' : 'border-transparent')}
                />
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label>Icon</Label>
            <div className="flex flex-wrap gap-2">
              {ICON_OPTIONS.map((ic) => {
                const Icon = (LucideIcons as any)[ic];
                return (
                  <button
                    key={ic}
                    onClick={() => setIcon(ic)}
                    className={cn('w-10 h-10 rounded-lg flex items-center justify-center border-2 transition-all', icon === ic ? 'border-primary bg-primary/10' : 'border-border')}
                  >
                    {Icon && <Icon className="w-5 h-5" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Create'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
