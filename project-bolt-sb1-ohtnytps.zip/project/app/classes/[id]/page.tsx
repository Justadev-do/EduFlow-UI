'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';
import type { Course, Assignment, Grade, GradeCategory } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { AssignmentCard } from '@/components/shared/assignment-card';
import { calculateCourseGrade, getLetterGrade } from '@/lib/grading';
import { getLetterGradeColor, getCourseColor } from '@/lib/course-utils';
import { cn } from '@/lib/utils';
import { ArrowLeft, BookOpen, GraduationCap, ClipboardList, TrendingUp, Plus } from 'lucide-react';
import Link from 'next/link';
import * as LucideIcons from 'lucide-react';

export default function ClassDetailPage() {
  return (
    <AppShell>
      <ClassDetailContent />
    </AppShell>
  );
}

function ClassDetailContent() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const courseId = params.id as string;
  const [course, setCourse] = useState<Course | null>(null);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [categories, setCategories] = useState<GradeCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !courseId) return;
    (async () => {
      const [cRes, aRes, gRes, catRes] = await Promise.all([
        supabase.from('courses').select('*').eq('id', courseId).maybeSingle(),
        supabase.from('assignments').select('*').eq('course_id', courseId).order('due_date'),
        supabase.from('grades').select('*').eq('course_id', courseId),
        supabase.from('grade_categories').select('*').eq('course_id', courseId),
      ]);
      setCourse(cRes.data as Course | null);
      setAssignments((aRes.data as Assignment[]) ?? []);
      setGrades((gRes.data as Grade[]) ?? []);
      setCategories((catRes.data as GradeCategory[]) ?? []);
      setLoading(false);
    })();
  }, [user, courseId]);

  if (loading) {
    return <div className="space-y-4 max-w-5xl mx-auto">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />)}</div>;
  }

  if (!course) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Class not found.</p>
        <Link href="/classes"><Button variant="outline" className="mt-4">Back to Classes</Button></Link>
      </div>
    );
  }

  const result = calculateCourseGrade(course, grades, categories);
  const colors = getCourseColor(course.color);
  const Icon = (LucideIcons as any)[course.icon] ?? BookOpen;
  const upcoming = assignments.filter((a) => a.status !== 'completed');
  const completed = assignments.filter((a) => a.status === 'completed');

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <Button variant="ghost" onClick={() => router.push('/classes')} className="mb-2">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Classes
      </Button>

      {/* Header */}
      <Card className={cn('p-6 border-l-4', colors.border)}>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={cn('flex items-center justify-center w-14 h-14 rounded-xl', colors.bg)}>
              <Icon className={cn('w-7 h-7', colors.text)} />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{course.name}</h2>
              <p className="text-sm text-muted-foreground">{course.teacher || 'No teacher'} · {course.period || 'No period'} · {course.room || 'No room'}</p>
            </div>
          </div>
          {result.percentage > 0 && (
            <div className="text-right">
              <div className={cn('text-3xl font-bold', getLetterGradeColor(result.letterGrade))}>{result.letterGrade}</div>
              <div className="text-sm text-muted-foreground">{result.percentage.toFixed(1)}%</div>
            </div>
          )}
        </div>
      </Card>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="grades">Grades</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card className="p-4 text-center">
              <ClipboardList className="w-5 h-5 text-primary mx-auto mb-1" />
              <p className="text-2xl font-bold">{upcoming.length}</p>
              <p className="text-xs text-muted-foreground">Upcoming</p>
            </Card>
            <Card className="p-4 text-center">
              <Check className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
              <p className="text-2xl font-bold">{completed.length}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </Card>
            <Card className="p-4 text-center">
              <GraduationCap className="w-5 h-5 text-blue-500 mx-auto mb-1" />
              <p className="text-2xl font-bold">{grades.length}</p>
              <p className="text-xs text-muted-foreground">Grades</p>
            </Card>
            <Card className="p-4 text-center">
              <TrendingUp className="w-5 h-5 text-amber-500 mx-auto mb-1" />
              <p className="text-2xl font-bold">{result.percentage > 0 ? `${result.percentage.toFixed(0)}%` : '—'}</p>
              <p className="text-xs text-muted-foreground">Current</p>
            </Card>
          </div>

          {result.details.length > 0 && result.details[0].count > 0 && (
            <Card className="p-5">
              <h3 className="font-semibold mb-3">Grade Breakdown</h3>
              <div className="space-y-2">
                {result.details.map((d, i) => (
                  <div key={i} className="flex items-center justify-between text-sm p-2 rounded-md bg-muted/50">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{d.categoryName}</span>
                      {d.weight !== 100 && <span className="text-xs text-muted-foreground">({d.weight}%)</span>}
                    </div>
                    <span className="font-semibold">{d.percentage.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Assignments */}
        <TabsContent value="assignments" className="space-y-2">
          {assignments.length === 0 ? (
            <Card className="p-8 text-center">
              <ClipboardList className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No assignments for this class yet.</p>
              <Link href="/assignments">
                <Button size="sm" variant="outline" className="mt-3">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Assignment
                </Button>
              </Link>
            </Card>
          ) : (
            assignments.map((a) => (
              <AssignmentCard key={a.id} assignment={a} course={course} />
            ))
          )}
        </TabsContent>

        {/* Grades */}
        <TabsContent value="grades" className="space-y-2">
          {grades.length === 0 ? (
            <Card className="p-8 text-center">
              <GraduationCap className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No grades entered yet.</p>
              <Link href="/grades">
                <Button size="sm" variant="outline" className="mt-3">Add Grade</Button>
              </Link>
            </Card>
          ) : (
            <Card className="p-5">
              <div className="space-y-2">
                {grades.map((g) => (
                  <div key={g.id} className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                    <div>
                      <p className="text-sm font-medium">{g.title}</p>
                      <p className="text-xs text-muted-foreground">{g.graded_date ?? 'Not graded'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{g.points_earned ?? '?'}/{g.points_possible}</p>
                      <p className="text-xs text-muted-foreground">
                        {g.points_earned != null ? `${((g.points_earned / g.points_possible) * 100).toFixed(1)}%` : 'Missing'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
