'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabase/client';
import type { AIConversation, AIMessage, Assignment, Course, AIMode } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { Sparkles, Send, Lightbulb, BookOpen, ListOrdered, CheckCheck, GraduationCap, Plus, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

const MODES: { id: AIMode; label: string; icon: any; description: string }[] = [
  { id: 'hint', label: 'Hint', icon: Lightbulb, description: 'Get the smallest useful hint' },
  { id: 'explain', label: 'Explain', icon: BookOpen, description: 'Understand the concept' },
  { id: 'step-by-step', label: 'Step-by-Step', icon: ListOrdered, description: 'Guided through one step at a time' },
  { id: 'check-work', label: 'Check My Work', icon: CheckCheck, description: 'Analyze your attempted work' },
  { id: 'teach', label: 'Teach Me', icon: GraduationCap, description: 'Learn the concept with examples' },
];

export default function AIPage() {
  return (
    <AppShell>
      <AIContent />
    </AppShell>
  );
}

function AIContent() {
  const { user } = useAuth();
  const searchParams = useSearchParams();
  const assignmentId = searchParams.get('assignment');
  const [conversations, setConversations] = useState<AIConversation[]>([]);
  const [currentConv, setCurrentConv] = useState<AIConversation | null>(null);
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<AIMode>('explain');
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [thinking, setThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [cRes, aRes, courseRes] = await Promise.all([
        supabase.from('ai_conversations').select('*').eq('user_id', user.id).order('updated_at', { ascending: false }),
        supabase.from('assignments').select('*').eq('user_id', user.id),
        supabase.from('courses').select('*').eq('user_id', user.id),
      ]);
      setConversations((cRes.data as AIConversation[]) ?? []);
      setAssignments((aRes.data as Assignment[]) ?? []);
      setCourses((courseRes.data as Course[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  useEffect(() => {
    if (currentConv) {
      supabase.from('ai_messages').select('*').eq('conversation_id', currentConv.id).order('created_at')
        .then(({ data }) => setMessages((data as AIMessage[]) ?? []));
    } else {
      setMessages([]);
    }
  }, [currentConv]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startNewConversation = async () => {
    if (!user) return;
    const assignment = assignmentId ? assignments.find((a) => a.id === assignmentId) : null;
    const course = assignment ? courses.find((c) => c.id === assignment.course_id) : null;
    const title = assignment ? assignment.title : 'New Conversation';

    const { data, error } = await supabase.from('ai_conversations').insert({
      user_id: user.id,
      title,
      assignment_id: assignmentId || null,
      course_id: assignment?.course_id ?? null,
      mode,
    }).select().single();

    if (error) { toast.error('Failed to start conversation'); return; }
    const newConv = data as AIConversation;
    setConversations((prev) => [newConv, ...prev]);
    setCurrentConv(newConv);

    const greeting = assignment
      ? `Hi! I'm your EduFlow AI Tutor. I see you're working on "${assignment.title}"${course ? ` for ${course.name}` : ''}. What would you like help with? I can give hints, explain concepts, or guide you step by step — but I won't just give you the answer. That's how you learn!`
      : `Hi! I'm your EduFlow AI Tutor. What are you learning today? I can help you understand concepts, work through problems step by step, or check your work. I'll guide you, but you'll do the thinking!`;

    const { data: msgData } = await supabase.from('ai_messages').insert({
      conversation_id: newConv.id,
      role: 'assistant',
      content: greeting,
    }).select().single();

    if (msgData) setMessages([msgData as AIMessage]);
  };

  const sendMessage = async () => {
    if (!input.trim() || !currentConv) return;
    const userMsg = input.trim();
    setInput('');
    setThinking(true);

    const { data: msgData } = await supabase.from('ai_messages').insert({
      conversation_id: currentConv.id,
      role: 'user',
      content: userMsg,
    }).select().single();

    if (msgData) setMessages((prev) => [...prev, msgData as AIMessage]);

    // Generate tutoring response based on mode
    const response = generateTutorResponse(userMsg, mode);

    await new Promise((r) => setTimeout(r, 800));

    const { data: aiMsgData } = await supabase.from('ai_messages').insert({
      conversation_id: currentConv.id,
      role: 'assistant',
      content: response,
    }).select().single();

    if (aiMsgData) setMessages((prev) => [...prev, aiMsgData as AIMessage]);
    setThinking(false);
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><p className="text-muted-foreground">Loading...</p></div>;
  }

  return (
    <div className="flex gap-4 max-w-7xl mx-auto h-[calc(100vh-8rem)]">
      {/* Sidebar - Conversations */}
      <div className="hidden md:flex flex-col w-64 shrink-0 space-y-2">
        <Button onClick={startNewConversation} className="w-full">
          <Plus className="w-4 h-4 mr-2" />
          New Conversation
        </Button>
        <div className="flex-1 overflow-auto space-y-1">
          {conversations.map((c) => (
            <button
              key={c.id}
              onClick={() => setCurrentConv(c)}
              className={cn(
                'w-full text-left p-3 rounded-lg transition-colors',
                currentConv?.id === c.id ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted'
              )}
            >
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 shrink-0 text-muted-foreground" />
                <span className="text-sm font-medium truncate">{c.title}</span>
              </div>
            </button>
          ))}
          {conversations.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-4">No conversations yet</p>
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {!currentConv ? (
          <Card className="flex-1 flex flex-col items-center justify-center p-12 text-center">
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold">EduFlow AI Tutor</h2>
            <p className="text-muted-foreground mt-2 max-w-md">
              I teach, I don't do. I'll help you understand concepts, work through problems, and check your work — but you'll do the thinking.
            </p>

            {/* Mode selector */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-6 max-w-lg w-full">
              {MODES.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={cn(
                    'p-3 rounded-lg border text-left transition-all',
                    mode === m.id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted'
                  )}
                >
                  <m.icon className="w-5 h-5 mb-1 text-primary" />
                  <p className="text-sm font-semibold">{m.label}</p>
                  <p className="text-xs text-muted-foreground">{m.description}</p>
                </button>
              ))}
            </div>

            <Button onClick={startNewConversation} className="mt-6">
              <Sparkles className="w-4 h-4 mr-2" />
              Start Learning
            </Button>
          </Card>
        ) : (
          <>
            {/* Messages */}
            <div className="flex-1 overflow-auto space-y-4 p-4">
              {messages.map((m) => (
                <div key={m.id} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div className={cn(
                    'max-w-[80%] p-3 rounded-2xl',
                    m.role === 'user' ? 'bg-primary text-primary-foreground rounded-br-sm' : 'bg-muted rounded-bl-sm'
                  )}>
                    <p className="text-sm whitespace-pre-wrap">{m.content}</p>
                  </div>
                </div>
              ))}
              {thinking && (
                <div className="flex justify-start">
                  <div className="bg-muted p-3 rounded-2xl rounded-bl-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Mode selector + input */}
            <div className="border-t p-3 space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                {MODES.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className={cn(
                      'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all',
                      mode === m.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-accent'
                    )}
                  >
                    <m.icon className="w-3 h-3" />
                    {m.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask me anything... I'll guide you, not give you the answer."
                  className="min-h-[44px] max-h-32 resize-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                />
                <Button onClick={sendMessage} disabled={!input.trim() || thinking} size="icon" className="shrink-0">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function generateTutorResponse(userMsg: string, mode: AIMode): string {
  const msg = userMsg.toLowerCase();

  // Detect "give me the answer" patterns
  if (msg.includes('give me the answer') || msg.includes('just tell me') || msg.includes('solve it for me') || msg.includes('write my essay') || msg.includes('write it for me')) {
    return "I'm here to help you learn, not to do the work for you. Let's work through this together instead. What part are you stuck on? I can give you a hint, explain the concept, or guide you step by step.";
  }

  // Math detection
  if (msg.includes('3x + 7 = 25') || msg.includes('3x+7=25')) {
    if (mode === 'hint') return "We want to isolate x. What operation could remove the +7 from the left side?";
    if (mode === 'step-by-step') return "Let's go step by step. First, we want to isolate x. What's on the same side as x? That's right, +7. What operation would cancel out +7?";
    if (mode === 'check-work') {
      if (msg.includes('3x = 32')) return "Check the subtraction in your second line. What is 25 - 7? Take another look at that step.";
      return "Show me what you've tried so far and I'll check your work!";
    }
    return "To solve a linear equation like 3x + 7 = 25, we want to get x by itself. The goal is to isolate x on one side. What do you think we should do first?";
  }

  // Density
  if (msg.includes('density')) {
    return "Density is calculated using mass divided by volume: D = m/V. What measurements does your problem give you? Once you know the mass and volume, you can divide them to find density.";
  }

  // Essay
  if (msg.includes('essay') || msg.includes('write')) {
    return "I can help you understand the prompt, brainstorm ideas, build an outline, or improve your reasoning — but you should write the final response yourself. What's the topic or prompt you're working with?";
  }

  // Generic responses by mode
  switch (mode) {
    case 'hint':
      return "Here's a small hint: think about what you already know and what the question is really asking. What's the first thing that comes to mind?";
    case 'explain':
      return "Let me explain the concept. Could you tell me which specific topic or problem you're working on? That way I can tailor my explanation to exactly what you need.";
    case 'step-by-step':
      return "Let's work through this one step at a time. First, what is the problem asking you to find? Once we know the goal, we can figure out the steps together.";
    case 'check-work':
      return "I'd love to check your work! Share what you've tried so far — write out your steps — and I'll look for any errors or places to improve.";
    case 'teach':
      return "I'll teach you this concept! First, let me ask: what do you already know about this topic? That way I can build on what you understand.";
    default:
      return "I'm here to help you learn! What specifically are you working on?";
  }
}
