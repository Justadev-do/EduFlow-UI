'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { useTheme, THEME_PRESETS, ACCENT_COLORS } from '@/lib/theme-context';
import { supabase } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { GraduationCap, ChevronRight, Check, Plug, Bell, Palette, BookOpen } from 'lucide-react';
import type { AccentColor, EducationLevel } from '@/lib/types';
import { toast } from 'sonner';

const STEPS = ['Welcome', 'Profile', 'Integrations', 'Notifications', 'Theme', 'Done'];

export default function OnboardingPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { setPreset, setAccent } = useTheme();
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [educationLevel, setEducationLevel] = useState<EducationLevel>('high-school');
  const [schoolName, setSchoolName] = useState('');
  const [selectedPreset, setSelectedPreset] = useState('default');
  const [selectedAccent, setSelectedAccent] = useState<AccentColor>('blue');

  const handleNext = async () => {
    if (step === 1) {
      await supabase.from('profiles').update({
        full_name: fullName,
        education_level: educationLevel,
        school_name: schoolName,
      }).eq('id', user!.id);
      await refreshProfile();
    }
    if (step === 4) {
      setPreset(selectedPreset);
      setAccent(selectedAccent);
    }
    if (step < STEPS.length - 1) {
      setStep(step + 1);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-lg space-y-6">
        {/* Progress */}
        <div className="flex items-center justify-center gap-2">
          {STEPS.map((s, i) => (
            <div
              key={i}
              className={cn(
                'h-2 rounded-full transition-all',
                i === step ? 'w-8 bg-primary' : i < step ? 'w-2 bg-primary' : 'w-2 bg-muted'
              )}
            />
          ))}
        </div>

        <Card className="p-6 md:p-8">
          {/* Step 0: Welcome */}
          {step === 0 && (
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-primary text-primary-foreground mx-auto">
                <GraduationCap className="w-9 h-9" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Welcome to EduFlow</h2>
                <p className="text-muted-foreground mt-2">Your school. Your schedule. One flow.</p>
              </div>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                EduFlow brings together your assignments, classes, grades, calendar, and study planning into one clean experience. Let's get you set up in a few quick steps.
              </p>
            </div>
          )}

          {/* Step 1: Profile */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">Tell us about you</h2>
              </div>
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Alex Johnson" />
              </div>
              <div className="space-y-2">
                <Label>Education Level</Label>
                <Select value={educationLevel} onValueChange={(v) => setEducationLevel(v as EducationLevel)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="middle-school">Middle School</SelectItem>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="college">College</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>School Name</Label>
                <Input value={schoolName} onChange={(e) => setSchoolName(e.target.value)} placeholder="Lincoln High School" />
              </div>
            </div>
          )}

          {/* Step 2: Integrations */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Plug className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">Connect your school</h2>
              </div>
              <p className="text-sm text-muted-foreground">You can connect these later. EduFlow works great on its own too.</p>
              <div className="space-y-3">
                {[
                  { name: 'Canvas LMS', desc: 'Sync courses, assignments, and grades', color: 'bg-red-500' },
                  { name: 'Google Calendar', desc: 'Sync assignments as calendar events', color: 'bg-blue-500' },
                  { name: 'ClassLink SSO', desc: 'Single sign-on for your school district', color: 'bg-green-500' },
                ].map((int, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className={cn('w-8 h-8 rounded-lg', int.color, '/10')} />
                      <div>
                        <p className="text-sm font-medium">{int.name}</p>
                        <p className="text-xs text-muted-foreground">{int.desc}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">Connect</Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Notifications */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Bell className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">Notification preferences</h2>
              </div>
              <p className="text-sm text-muted-foreground">Choose what you want to be notified about. You can change these anytime in Settings.</p>
              <div className="space-y-2">
                {['Assignment due tomorrow', 'Assignment due today', 'Assignment overdue', 'Grade posted', 'Test approaching'].map((n, i) => (
                  <label key={i} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded" />
                    <span className="text-sm">{n}</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Theme */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Palette className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">Pick your theme</h2>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {THEME_PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPreset(p.id)}
                    className={cn(
                      'p-3 rounded-lg border-2 transition-all text-left',
                      selectedPreset === p.id ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-primary/50'
                    )}
                  >
                    <div className="flex gap-1 mb-2">
                      <div className="w-5 h-5 rounded" style={{ background: `hsl(${p.vars['--background']})` }} />
                      <div className="w-5 h-5 rounded" style={{ background: `hsl(${p.vars['--primary']})` }} />
                    </div>
                    <p className="text-xs font-semibold">{p.name}</p>
                  </button>
                ))}
              </div>
              <div className="space-y-2">
                <Label>Accent Color</Label>
                <div className="flex flex-wrap gap-2">
                  {(Object.keys(ACCENT_COLORS) as AccentColor[]).map((c) => (
                    <button
                      key={c}
                      onClick={() => setSelectedAccent(c)}
                      className={cn('w-10 h-10 rounded-full border-2 transition-all', selectedAccent === c ? 'border-foreground scale-110' : 'border-transparent')}
                      style={{ background: `hsl(${ACCENT_COLORS[c]})` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Done */}
          {step === 5 && (
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-500/10 mx-auto">
                <Check className="w-9 h-9 text-emerald-500" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">You're all set!</h2>
                <p className="text-muted-foreground mt-2">Let's keep your schoolwork flowing.</p>
              </div>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Head to your dashboard to see what's due today, or start adding your classes and assignments.
              </p>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6 pt-4 border-t">
            {step > 0 ? (
              <Button variant="ghost" onClick={() => setStep(step - 1)}>Back</Button>
            ) : <div />}
            <Button onClick={handleNext}>
              {step === STEPS.length - 1 ? 'Go to Dashboard' : step === 0 ? 'Get Started' : 'Next'}
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
