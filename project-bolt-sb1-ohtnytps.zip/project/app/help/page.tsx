'use client';

import { AppShell } from '@/components/layout/app-shell';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GraduationCap, BookOpen, Calendar, ClipboardList, Sparkles, Settings, HelpCircle, Mail, ExternalLink } from 'lucide-react';
import Link from 'next/link';

export default function HelpPage() {
  return (
    <AppShell>
      <HelpContent />
    </AppShell>
  );
}

function HelpContent() {
  const faqs = [
    { q: 'How do I add a class?', a: 'Go to the Classes page and click "Add Class". Fill in the name, teacher, color, and grading system.' },
    { q: 'How do I add an assignment?', a: 'Go to Assignments and click "Add Assignment". Choose a class, set the due date, priority, and estimated time.' },
    { q: 'How does the grading engine work?', a: 'EduFlow supports both points-based and weighted category grading. Go to Grades and click "What-If Calculator" to see how future assignments affect your grade.' },
    { q: 'What does the Planner do?', a: 'The Planner breaks large assignments into smaller daily tasks so you can work a little each day instead of cramming.' },
    { q: 'How does the AI Tutor work?', a: 'The AI Tutor teaches you how to solve problems — it does not give you answers. Choose a mode (Hint, Explain, Step-by-Step, Check My Work, or Teach Me) and start asking questions.' },
    { q: 'Can I change the theme?', a: 'Yes! Go to Themes to pick from preset themes like Midnight, Ocean, Forest, and more. You can also customize your accent color.' },
    { q: 'Is my data private?', a: 'Your data belongs to you. You can export it or delete your account at any time from Settings > Privacy.' },
  ];

  const guides = [
    { title: 'Getting Started', desc: 'Set up your classes and assignments', icon: BookOpen, href: '/classes' },
    { title: 'Managing Assignments', desc: 'Create, organize, and track your work', icon: ClipboardList, href: '/assignments' },
    { title: 'Understanding Grades', desc: 'Learn about weighted categories and what-if calculations', icon: GraduationCap, href: '/grades' },
    { title: 'Using the Planner', desc: 'Break assignments into manageable steps', icon: Calendar, href: '/planner' },
    { title: 'AI Tutor Guide', desc: 'Learn how to get the most from your AI tutor', icon: Sparkles, href: '/ai' },
    { title: 'Customize Your Theme', desc: 'Personalize EduFlow with themes and accent colors', icon: Settings, href: '/themes' },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Help Center</h2>
        <p className="text-sm text-muted-foreground">Guides and answers to help you get the most out of EduFlow</p>
      </div>

      {/* Quick guides */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {guides.map((g, i) => (
          <Link key={i} href={g.href}>
            <Card className="p-4 hover:shadow-md transition-all cursor-pointer h-full">
              <div className="flex items-start gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 shrink-0">
                  <g.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{g.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{g.desc}</p>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {/* FAQ */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-primary" />
          Frequently Asked Questions
        </h3>
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i}>
              <p className="font-medium text-sm mb-1">{faq.q}</p>
              <p className="text-sm text-muted-foreground">{faq.a}</p>
              {i < faqs.length - 1 && <div className="mt-4 border-t" />}
            </div>
          ))}
        </div>
      </Card>

      {/* Contact */}
      <Card className="p-5 text-center">
        <Mail className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-semibold">Still need help?</h3>
        <p className="text-sm text-muted-foreground mt-1">We're here to help you succeed.</p>
        <Button variant="outline" className="mt-4">
          <ExternalLink className="w-4 h-4 mr-2" />
          Contact Support
        </Button>
      </Card>
    </div>
  );
}
