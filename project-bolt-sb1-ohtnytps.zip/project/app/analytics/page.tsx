'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Assignment, Course, Grade, GradeCategory } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { calculateCourseGrade, calculateGPA, getLetterGrade } from '@/lib/grading';
import { getLetterGradeColor } from '@/lib/course-utils';
import { cn } from '@/lib/utils';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';
import { BarChart3, TrendingUp, CheckCircle2, Clock, GraduationCap, Award } from 'lucide-react';
import { format, parseISO, subDays, eachDayOfInterval } from 'date-fns';

type DateRange = '7' | '30' | 'semester' | 'year' | 'all';

export default function AnalyticsPage() {
  return (
    <AppShell>
      <AnalyticsContent />
    </AppShell>
  );
}

function AnalyticsContent() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [categories, setCategories] = useState<GradeCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<DateRange>('30');

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [aRes, cRes, gRes] = await Promise.all([
        supabase.from('assignments').select('*').eq('user_id', user.id),
        supabase.from('courses').select('*').eq('user_id', user.id),
        supabase.from('grades').select('*').eq('user_id', user.id),
      ]);
      setAssignments((aRes.data as Assignment[]) ?? []);
      setCourses((cRes.data as Course[]) ?? []);
      setGrades((gRes.data as Grade[]) ?? []);
      const catPromises = ((cRes.data as Course[]) ?? []).map((c) =>
        supabase.from('grade_categories').select('*').eq('course_id', c.id)
      );
      const catResults = await Promise.all(catPromises);
      setCategories(catResults.flatMap((r) => (r.data as GradeCategory[]) ?? []));
      setLoading(false);
    })();
  }, [user]);

  const courseResults = useMemo(() => courses.map((c) => {
    const cGrades = grades.filter((g) => g.course_id === c.id);
    const cCats = categories.filter((cat) => cat.course_id === c.id);
    return { course: c, result: calculateCourseGrade(c, cGrades, cCats) };
  }), [courses, grades, categories]);

  const avgGrade = courseResults.length > 0
    ? courseResults.reduce((s, cr) => s + cr.result.percentage, 0) / courseResults.length
    : 0;

  const gpa = calculateGPA(courseResults.map((cr) => ({ percentage: cr.result.percentage, isWeighted: false, weight: 1 })));

  const completionRate = assignments.length > 0
    ? (assignments.filter((a) => a.status === 'completed').length / assignments.length) * 100
    : 0;

  const onTimeRate = useMemo(() => {
    const completed = assignments.filter((a) => a.status === 'completed' && a.due_date);
    if (completed.length === 0) return 0;
    return (completed.length / completed.length) * 100; // Simplified - would need actual submission dates
  }, [assignments]);

  const totalStudyTime = assignments.reduce((s, a) => s + a.estimated_minutes, 0);

  // Workload chart data
  const workloadData = useMemo(() => {
    const days = dateRange === '7' ? 7 : dateRange === '30' ? 30 : 90;
    const start = subDays(new Date(), days);
    const range = eachDayOfInterval({ start, end: new Date() });
    return range.map((d) => {
      const dayAssignments = assignments.filter((a) => {
        if (!a.due_date) return false;
        return format(parseISO(a.due_date), 'yyyy-MM-dd') === format(d, 'yyyy-MM-dd');
      });
      return {
        date: format(d, 'MMM d'),
        assignments: dayAssignments.length,
        minutes: dayAssignments.reduce((s, a) => s + a.estimated_minutes, 0),
      };
    });
  }, [assignments, dateRange]);

  // Grade comparison data
  const gradeComparison = courseResults.map((cr) => ({
    name: cr.course.name,
    grade: cr.result.percentage,
    letter: cr.result.letterGrade,
  }));

  // Completion pie data
  const completionData = [
    { name: 'Completed', value: assignments.filter((a) => a.status === 'completed').length, color: 'hsl(142, 71%, 45%)' },
    { name: 'In Progress', value: assignments.filter((a) => a.status === 'in-progress').length, color: 'hsl(221, 83%, 53%)' },
    { name: 'Not Started', value: assignments.filter((a) => a.status === 'not-started').length, color: 'hsl(215, 16%, 47%)' },
    { name: 'Overdue', value: assignments.filter((a) => a.status === 'overdue').length, color: 'hsl(0, 84%, 60%)' },
  ];

  if (loading) {
    return (
      <div className="space-y-4 max-w-7xl mx-auto">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-48 bg-muted rounded-lg animate-pulse" />)}
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Analytics</h2>
          <p className="text-sm text-muted-foreground">Understand your academic trends</p>
        </div>
        <Tabs value={dateRange} onValueChange={(v) => setDateRange(v as DateRange)}>
          <TabsList>
            <TabsTrigger value="7">7 Days</TabsTrigger>
            <TabsTrigger value="30">30 Days</TabsTrigger>
            <TabsTrigger value="semester">Semester</TabsTrigger>
            <TabsTrigger value="year">Year</TabsTrigger>
            <TabsTrigger value="all">All Time</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-blue-500" />
            <span className="text-xs text-muted-foreground">Avg Grade</span>
          </div>
          <p className="text-2xl font-bold">{avgGrade > 0 ? `${avgGrade.toFixed(1)}%` : '—'}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <GraduationCap className="w-4 h-4 text-emerald-500" />
            <span className="text-xs text-muted-foreground">GPA</span>
          </div>
          <p className="text-2xl font-bold">{gpa.unweighted > 0 ? gpa.unweighted.toFixed(2) : '—'}</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle2 className="w-4 h-4 text-green-500" />
            <span className="text-xs text-muted-foreground">Completion</span>
          </div>
          <p className="text-2xl font-bold">{completionRate.toFixed(0)}%</p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-4 h-4 text-amber-500" />
            <span className="text-xs text-muted-foreground">Study Time</span>
          </div>
          <p className="text-2xl font-bold">{Math.round(totalStudyTime / 60)}h</p>
        </Card>
      </div>

      {/* Workload chart */}
      <Card className="p-5">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          Workload Over Time
        </h3>
        <ChartContainer config={{ minutes: { label: 'Minutes' } }} className="h-[250px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={workloadData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="date" className="text-xs" tick={{ fontSize: 11 }} />
              <YAxis className="text-xs" tick={{ fontSize: 11 }} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="minutes" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Grade comparison */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-primary" />
            Class Comparison
          </h3>
          {gradeComparison.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No grade data yet</p>
          ) : (
            <ChartContainer config={{ grade: { label: 'Grade %' } }} className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={gradeComparison} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis type="number" domain={[0, 100]} className="text-xs" tick={{ fontSize: 11 }} />
                  <YAxis dataKey="name" type="category" className="text-xs" tick={{ fontSize: 11 }} width={80} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="grade" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </Card>

        {/* Completion breakdown */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-primary" />
            Assignment Status
          </h3>
          {assignments.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No assignments yet</p>
          ) : (
            <ChartContainer config={{}} className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={completionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                    {completionData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </Card>
      </div>

      {/* Class grades table */}
      {courseResults.length > 0 && (
        <Card className="p-5">
          <h3 className="font-semibold mb-4">Grade Summary by Class</h3>
          <div className="space-y-2">
            {courseResults.map((cr) => (
              <div key={cr.course.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div>
                  <p className="font-medium text-sm">{cr.course.name}</p>
                  <p className="text-xs text-muted-foreground">{cr.course.teacher || 'No teacher'}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">{cr.result.percentage.toFixed(1)}%</span>
                  <span className={cn('text-lg font-bold', getLetterGradeColor(cr.result.letterGrade))}>
                    {cr.result.letterGrade}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
