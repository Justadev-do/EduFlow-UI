'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Notification } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Bell, Check, Clock, AlertCircle, GraduationCap, Calendar, Sparkles, Info } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { toast } from 'sonner';

const ICON_MAP: Record<string, any> = {
  'assignment-due': Clock,
  'overdue': AlertCircle,
  'grade-posted': GraduationCap,
  'grade-changed': GraduationCap,
  'test-approaching': AlertCircle,
  'study-reminder': Calendar,
  'system': Info,
};

export default function NotificationsPage() {
  return (
    <AppShell>
      <NotificationsContent />
    </AppShell>
  );
}

function NotificationsContent() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    if (!user) return;
    const { data } = await supabase.from('notifications').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setNotifications((data as Notification[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { loadData(); }, [user]);

  const markAllRead = async () => {
    if (!user) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    toast.success('All notifications marked as read');
  };

  const markRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true } : n));
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
          <p className="text-sm text-muted-foreground">
            {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up'}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={markAllRead}>
            <Check className="w-4 h-4 mr-2" />
            Mark all read
          </Button>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />)}
        </div>
      ) : notifications.length === 0 ? (
        <Card className="p-12 text-center">
          <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-lg">No notifications</h3>
          <p className="text-sm text-muted-foreground mt-1">You're all caught up. Nothing new here.</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => {
            const Icon = ICON_MAP[n.notification_type] ?? Info;
            return (
              <Card
                key={n.id}
                className={cn(
                  'p-4 flex items-start gap-3 transition-all cursor-pointer hover:shadow-md',
                  !n.is_read && 'border-l-4 border-l-primary bg-primary/5'
                )}
                onClick={() => markRead(n.id)}
              >
                <div className={cn(
                  'flex items-center justify-center w-10 h-10 rounded-lg shrink-0',
                  n.notification_type === 'overdue' ? 'bg-red-500/10' : 'bg-muted'
                )}>
                  <Icon className={cn('w-5 h-5', n.notification_type === 'overdue' ? 'text-red-500' : 'text-muted-foreground')} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{n.title}</p>
                    {!n.is_read && <span className="w-2 h-2 rounded-full bg-primary shrink-0" />}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{format(parseISO(n.created_at), 'MMM d, h:mm a')}</p>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
