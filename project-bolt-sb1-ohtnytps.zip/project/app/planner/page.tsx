'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useAuth } from '@/lib/auth-context';
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Assignment, Course, PlannerTask, StudySession } from '@/lib/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { getCourseColor, formatDuration } from '@/lib/date-utils';
import { format, addDays, parseISO, isToday, differenceInDays } from 'date-fns';
import { CalendarClock, Plus, Check, Clock, Sparkles, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function PlannerPage() {
  return (
    <AppShell>
      <PlannerContent />
    </AppShell>
  );
}

function PlannerContent() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [plannerTasks, setPlannerTasks] = useState<PlannerTask[]>([]);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!user) return;
    const [aRes, cRes, sRes] = await Promise.all([
      supabase.from('assignments').select('*').eq('user_id', user.id),
      supabase.from('courses').select('*').eq('user_id', user.id),
      supabase.from('study_sessions').select('*').eq('user_id', user.id),
    ]);
    setAssignments((aRes.data as Assignment[]) ?? []);
    setCourses((cRes.data as Course[]) ?? []);
    setStudySessions((sRes.data as StudySession[]) ?? []);

    const activeAssignments = ((aRes.data as Assignment[]) ?? []).filter((a) => a.status !== 'completed');
    const taskPromises = activeAssignments.map((a) =>
      supabase.from('planner_tasks').select('*').eq('assignment_id', a.id).order('planned_date')
    );
    const taskResults = await Promise.all(taskPromises);
    setPlannerTasks(taskResults.flatMap((r) => (r.data as PlannerTask[]) ?? []));
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  const activeAssignments = assignments.filter((a) => a.status !== 'completed');

  const generatePlan = async (assignment: Assignment) => {
    if (!assignment.due_date) { toast.error('Assignment needs a due date to plan'); return; }
    const dueDate = parseISO(assignment.due_date);
    const today = new Date();
    const daysAvailable = Math.max(1, differenceInDays(dueDate, today));
    const totalMinutes = assignment.estimated_minutes;
    const minutesPerDay = Math.max(10, Math.ceil(totalMinutes / daysAvailable));

    const tasks: { assignment_id: string; title: string; planned_date: string; duration_minutes: number; sort_order: number }[] = [];
    const steps = ['Research', 'Outline', 'Draft', 'Revise', 'Final Review'];
    const numSteps = Math.min(steps.length, daysAvailable);
    for (let i = 0; i < numSteps; i++) {
      tasks.push({
        assignment_id: assignment.id,
        title: steps[i],
        planned_date: format(addDays(today, i), 'yyyy-MM-dd'),
        duration_minutes: Math.ceil(totalMinutes / numSteps),
        sort_order: i,
      });
    }

    const { data, error } = await supabase.from('planner_tasks').insert(tasks).select();
    if (error) { toast.error('Failed to generate plan'); return; }
    if (data) setPlannerTasks((prev) => [...prev, ...(data as PlannerTask[])]);
    toast.success('Plan generated!');
  };

  const toggleTask = async (taskId: string, completed: boolean) => {
    await supabase.from('planner_tasks').update({ completed }).eq('id', taskId);
    setPlannerTasks((prev) => prev.map((t) => t.id === taskId ? { ...t, completed } : t));
  };

  const deleteTask = async (taskId: string) => {
    await supabase.from('planner_tasks').delete().eq('id', taskId);
    setPlannerTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  if (loading) {
    return (
      <div className="space-y-4 max-w-5xl mx-auto">
        {Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-40 bg-muted rounded-lg animate-pulse" />)}
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Planner</h2>
        <p className="text-sm text-muted-foreground">Break big assignments into manageable daily steps</p>
      </div>

      {activeAssignments.length === 0 ? (
        <Card className="p-12 text-center">
          <CalendarClock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-lg">Nothing to plan</h3>
          <p className="text-sm text-muted-foreground mt-1">All your assignments are completed. Great work!</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {activeAssignments.map((a) => {
            const course = courses.find((c) => c.id === a.course_id);
            const colors = course ? getCourseColor(course.color) : getCourseColor('blue');
            const tasks = plannerTasks.filter((t) => t.assignment_id === a.id);
            const completedTasks = tasks.filter((t) => t.completed).length;
            const progress = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0;

            return (
              <Card key={a.id} className={cn('p-5 border-l-4', colors.border)}>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      {course && <span className={cn('text-xs font-medium px-2 py-0.5 rounded-md', colors.bg, colors.text)}>{course.name}</span>}
                      <span className="text-xs text-muted-foreground">{formatDuration(a.estimated_minutes)} total</span>
                    </div>
                    <h3 className="font-semibold">{a.title}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {a.due_date ? `Due ${format(parseISO(a.due_date), 'MMM d')}` : 'No due date'}
                    </p>
                  </div>
                  {tasks.length === 0 ? (
                    <Button size="sm" variant="outline" onClick={() => generatePlan(a)}>
                      <Sparkles className="w-3 h-3 mr-1" />
                      Generate Plan
                    </Button>
                  ) : (
                    <div className="text-right">
                      <div className="text-xs text-muted-foreground">{completedTasks}/{tasks.length} done</div>
                      <div className="w-24 h-2 rounded-full bg-muted mt-1 overflow-hidden">
                        <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
                      </div>
                    </div>
                  )}
                </div>

                {tasks.length > 0 && (
                  <div className="space-y-2 mt-3 pt-3 border-t">
                    {tasks.map((t) => (
                      <div key={t.id} className="flex items-center gap-3 p-2 rounded-md bg-muted/30">
                        <button
                          onClick={() => toggleTask(t.id, !t.completed)}
                          className={cn(
                            'w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all shrink-0',
                            t.completed ? 'bg-primary border-primary' : 'border-border hover:border-primary'
                          )}
                        >
                          {t.completed && <Check className="w-3 h-3 text-primary-foreground" />}
                        </button>
                        <div className="flex-1 min-w-0">
                          <p className={cn('text-sm font-medium', t.completed && 'line-through text-muted-foreground')}>{t.title}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{formatDuration(t.duration_minutes)}</span>
                            <span>{format(parseISO(t.planned_date), 'EEE, MMM d')}</span>
                          </div>
                        </div>
                        <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => deleteTask(t.id)}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
